<?php
/*
  Template Name: Landing
 */
?>
<?php
$options = thrive_get_options_for_post( get_the_ID() );
get_header();
?>

<header>
	<?php if ( $options['logo_type'] == "text" ): ?>
		<div id="text_logo"
		     class="<?php if ( $options['logo_color'] == "default" ): ?>default_color<?php else: ?><?php echo $options['logo_color'] ?><?php endif; ?>">
			<a href="<?php echo home_url( '/' ); ?>"><?php echo $options['logo_text']; ?></a>
		</div>
	<?php elseif ( ! empty( $options['logo'] ) ): ?>
		<a href="<?php echo home_url( '/' ); ?>" id="logo" class="logo">
			<img src="<?php echo $options['logo']; ?>"
			     alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>"/>
		</a>
	<?php endif; ?>
</header>

<section class="bSe lnd "><!--Start the section wrapper-->
	<?php
	if ( thrive_check_top_focus_area() ):
		thrive_render_top_focus_area();
	endif;
	?>
	<div class="wrp">
		<?php get_template_part( 'breadcrumbs' ); ?>
		<?php if ( have_posts() ): ?>
			<?php while ( have_posts() ): ?>
				<?php the_post(); ?>
				<?php get_template_part( 'content', 'single' ); ?>

				<?php
				if ( thrive_check_bottom_focus_area() ):
					thrive_render_top_focus_area( "bottom" );
					?>
				<?php endif; ?>

				<?php if ( ! post_password_required() ) : ?>
					<?php comments_template( '', true ); ?>
				<?php elseif ( ( ! comments_open() ) && get_comments_number() > 0 ): ?>
					<?php comments_template( '/comments-disabled.php' ); ?>
				<?php endif; ?>
			<?php endwhile; ?>

			<div class="clear"></div>

		<?php else: ?>
			<!--No contents-->
		<?php endif ?>
	</div>
	<?php get_footer(); ?>