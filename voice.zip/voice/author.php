<?php
$options        = thrive_get_theme_options();
$next_page_link = get_next_posts_link();
$prev_page_link = get_previous_posts_link();
$author_info    = _thrive_get_sidebar_author_info( $options );
?>

<?php get_header(); ?>

<?php get_sidebar(); ?>

<section class="bSe fullWidth idx"><!--Start the section wrapper-->

	<?php if ( _thrive_check_focus_area_for_pages( "archive", "top" ) ): ?>
		<?php if ( strpos( $options['blog_layout'], 'masonry' ) === false && strpos( $options['blog_layout'], 'grid' ) === false ): ?>
			<?php thrive_render_top_focus_area( "top", "archive" ); ?>
		<?php endif; ?>
	<?php endif; ?>


	<div class="wrp">
		<?php get_template_part( 'breadcrumbs' ); ?>

		<article class="ach">
			<div class="cnt">
				<div class="achw">
					<h6><?php _e( "All Posts by", 'thrive' ); ?> <a
							href="<?php echo $author_info['posts_url']; ?>"><?php echo $author_info['display_name']; ?></a>
					</h6>
					<?php echo $author_info['description']; ?>
					<?php if ( ! empty( $author_info['author_website'] ) ): ?>
						<a href="<?php echo $author_info['author_website']; ?>"><?php _e( "Read the full story here", 'thrive' ); ?>
							&gt;</a>
					<?php endif; ?>
				</div>
				<?php if ( count( $author_info['social_links'] ) > 0 ): ?>
					<ul class="achs">
						<?php
						foreach ( $author_info['social_links'] as $service => $url ):
							if ( in_array( $service, $author_info['show_social_profiles'] ) || empty( $author_info['show_social_profiles'][0] ) ) {
								$url = _thrive_get_social_link( $url, $service );
								?>
								<li>
									<a href="<?php echo $url; ?>" class="<?php echo $service; ?>" target="_blank"></a>
								</li>
								<?php
							}
						endforeach;
						?>
					</ul>
				<?php endif; ?>
			</div>
		</article>

		<?php if ( have_posts() ): ?>
			<?php while ( have_posts() ): ?>
				<?php the_post(); ?>
				<?php get_template_part( 'content' ); ?>
			<?php endwhile; ?>
			<div class="clear"></div>

			<?php if ( _thrive_check_focus_area_for_pages( "archive", "bottom" ) ): ?>
				<?php if ( strpos( $options['blog_layout'], 'masonry' ) === false && strpos( $options['blog_layout'], 'grid' ) === false ): ?>
					<?php thrive_render_top_focus_area( "bottom", "archive" ); ?>
					<div class="spr"></div>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( $next_page_link || $prev_page_link && ( $next_page_link != "" || $prev_page_link != "" ) ): ?>
				<div class="awr ctr pgn clearfix">
					<?php thrive_pagination(); ?>
				</div>
				<div class="bspr"></div>
			<?php endif; ?>
		<?php else: ?>
			<!--No contents-->
		<?php endif ?>
	</div>
	<?php get_footer(); ?>