<?php
$options = thrive_get_theme_options();
get_header(); ?>

<?php get_sidebar(); ?>

<section class="bSe fullWidth idx"><!--Start the section wrapper-->

	<div class="wrp">
		<article class="lost">
			<div class="cnt">
				<div class="losti">
					<h1>404</h1>
					<p><?php _e( "The page you are trying to access doesn't exist. Try searching for it below or", 'thrive' ); ?></p>
					<p></p><a href="<?php echo home_url( '/' ); ?>"><?php _e( "click here", 'thrive' ); ?></a>
					<?php _e( "to return to the homepage.", 'thrive' ); ?></p>
				</div>
				<form action="<?php echo home_url( '/' ); ?>" method="get">
					<input type="text" name="s"/>
					<input type="submit" value="Search"/>
				</form>
				<?php if ( ! empty( $options['404_custom_text'] ) ): ?>
					<p><?php echo do_shortcode( $options['404_custom_text'] ); ?></p>
				<?php endif; ?>
				<?php
				if ( isset( $options['404_display_sitemap'] ) && $options['404_display_sitemap'] == "on" ):
					$categories = get_categories( array( 'parent' => 0 ) );
					$pages = get_pages();
					?>
					<div class="csc">
						<div class="colm thc">
							<h3><?php _e( "Categories", 'thrive' ); ?></h3>
							<ul class="tt_sitemap_list">
								<?php foreach ( $categories as $cat ): ?>
									<li>
										<a href='<?php echo get_category_link( $cat->term_id ); ?>'><?php echo $cat->name; ?></a>
										<?php
										$subcats = get_categories( array( 'child_of' => $cat->term_id ) );
										if ( count( $subcats ) > 0 ):
											?>
											<ul>
												<?php foreach ( $subcats as $subcat ): ?>
												<li>
													<a href='<?php echo get_category_link( $subcat->term_id ); ?>'><?php echo $subcat->name; ?></a>
													<?php endforeach; ?>
											</ul>
										<?php endif; ?>
									</li>
								<?php endforeach; ?>
							</ul>
						</div>
						<div class="colm thc">
							<h3><?php _e( "Archives", 'thrive' ); ?></h3>
							<ul>
								<?php wp_get_archives(); ?>
							</ul>
						</div>
						<div class="colm thc lst">
							<h3><?php _e( "Pages", 'thrive' ); ?></h3>
							<ul class="tt_sitemap_list">
								<?php foreach ( $pages as $page ): ?>
									<li>
										<a href='<?php echo get_page_link( $page->ID ); ?>'><?php echo get_the_title( $page->ID ); ?></a>
									</li>
								<?php endforeach; ?>
							</ul>
						</div>
						<div class="clear"></div>
					</div>
				<?php endif; ?>
				<div class="clear"></div>
			</div>
		</article>
	</div>

</section><!--End the section wrapper-->
<div class="clear"></div>
<?php tha_footer_after(); ?>
<?php if ( isset( $options['analytics_body_script'] ) && $options['analytics_body_script'] != "" ): ?>
	<?php echo $options['analytics_body_script']; ?>
<?php endif; ?>
<?php wp_footer(); ?>
<?php tha_body_bottom(); ?>
</body>
</html>