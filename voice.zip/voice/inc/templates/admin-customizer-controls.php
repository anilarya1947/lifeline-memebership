<?php

class ThriveTheme_Select_Font_Control1 extends WP_Customize_Control {

	public $type = 'select';

	public function render_content() {
		?>
		<label>
			<span class="customize-control-title">Headline Font</span>
			<span data-font-location="Header" class="button selectFont">Choose font</span>
			<input readonly class="selectedHeaderFont"/>
			<input type="hidden" class="fontSettingHeader" <?php $this->link(); ?>/>
		</label>

		<input type="hidden" id="font-location">
		<?php include 'admin-customizer-font-manager.php'; ?>

		<?php
	}

}

class ThriveTheme_Select_Font_Control2 extends WP_Customize_Control {

	public $type = 'select';

	public function render_content() {
		?>

		<label>
			<span class="customize-control-title">Body Font</span>
			<span data-font-location="Body" class="button selectFont">Choose font</span>
			<input readonly class="selectedBodyFont"/>
			<input type="hidden" class="fontSettingBody" <?php $this->link(); ?>/>
		</label>

		<?php
	}

}

class ThriveTheme_Select_Fontsize_Control extends WP_Customize_Control {

	public $type = 'select';
	public $thrive_font_sizes = array();

	public function render_content() {
		for ( $i = 10; $i < 72; $i ++ ) {
			$this->thrive_font_sizes[ $i ] = $i;
		}
		?>
		<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<select style="width: 100%;" <?php $this->link(); ?>>
				<?php foreach ( $this->thrive_font_sizes as $font ): ?>
					<option <?php if ( $this->value() == $font ): ?>selected<?php endif ?>><?php echo $font; ?></option>
				<?php endforeach ?>
			</select>
		</label>
		<?php
	}

}

class ThriveTheme_Select_Fontlineheight_Control extends WP_Customize_Control {

	public $type = 'select';
	public $thrive_line_heights = array( 0.8, 0.9, 1, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0 );

	public function render_content() {
		?>
		<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<select style="width: 100%;" <?php $this->link(); ?>>
				<?php foreach ( $this->thrive_line_heights as $font ): ?>
					<option <?php if ( $this->value() == $font ): ?>selected<?php endif ?>><?php echo $font; ?></option>
				<?php endforeach ?>
			</select>
		</label>
		<?php
	}

}

class ThriveTheme_Select_Case_Control extends WP_Customize_Control {

	public $type = 'select';
	public $thrive_font_options = array( 'Uppercase', 'Regular' );

	public function render_content() {
		?>
		<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<select style="width: 100%;" <?php $this->link(); ?>>
				<?php foreach ( $this->thrive_font_options as $font ): ?>
					<option <?php if ( $this->value() == $font ): ?>selected<?php endif ?>><?php echo $font; ?></option>
				<?php endforeach ?>
			</select>
		</label>
		<?php
	}

}

class ThriveTheme_Select_Weight_Control extends WP_Customize_Control {

	public $type = 'select';
	public $thrive_font_options = array( 'Bold', 'Normal' );

	public function render_content() {
		?>
		<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<select style="width: 100%;" <?php $this->link(); ?>>
				<?php foreach ( $this->thrive_font_options as $font ): ?>
					<option <?php if ( $this->value() == $font ): ?>selected<?php endif ?>><?php echo $font; ?></option>
				<?php endforeach ?>
			</select>
		</label>
		<?php
	}

}

class ThriveTheme_ResetDefaults_Control extends WP_Customize_Control {

	public $type = 'select';
	public $thrive_font_options = array( 'Uppercase', 'Regular' );

	public function render_content() {
		$wpnonce         = wp_create_nonce( "thrive_reset_customization" );
		$resetToDefaults = admin_url( 'admin-ajax.php?action=reset_customization&nonce=' . $wpnonce );
		?>
		<label>
			<input class="pure-button pure-button-error" type="button" id="thrive-reset-customization-btn"
			       value="Reset"/>
		</label>
		<script type="text/javascript">
			var ThriveCustomization = {};
			ThriveCustomization.resetUrl = "<?php echo $resetToDefaults; ?>";
			ThriveCustomization.noonce = "<?php echo $wpnonce; ?>";


			jQuery(document).ready(function () {
				jQuery("#thrive-reset-customization-btn").click(function () {
					var postData = {
						nonce: ThriveCustomization.noonce
					};
					jQuery.post(ThriveCustomization.resetUrl, postData, function (response) {
						location.reload();
					});
				});
			});

		</script>
		<?php
	}

}

class ThriveTheme_Select_PatternBg_Control extends WP_Customize_Control {

	public $type = 'select';

	public function render_content() {
		$patterns = _thrive_get_patterns_from_directory();
		?>
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/inc/css/thrive_admin_customize.css"/>
		<style>
			<?php foreach ($patterns as $pat): ?>
			<?php echo "#" . $pat . "{ background-image: url('" . get_template_directory_uri() . "/images/patterns/" . $pat . ".png');}"; ?>
			<?php endforeach; ?>
		</style>
		<label>
			<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
			<select <?php $this->link(); ?> id="thrive_select_customizer_pattern" style="display: none;">
				<?php foreach ( $patterns as $pat ): ?>
					<option <?php if ( $this->value() == $pat ): ?>selected<?php endif ?>
					        value="<?php echo $pat; ?>"><?php echo $pat; ?></option>
				<?php endforeach; ?>
			</select>
			<div class="patternSelect">
				<div class="defaultPattern">
					<span></span>
					<a href="" id="showPattern"></a>
					<div style="clear: both;"></div>
				</div>
				<ul class="patternList" style="display: none;">
					<?php foreach ( $patterns as $pat ): ?>
						<li>
							<a href="" id="<?php echo $pat; ?>"
							   <?php if ( $this->value() == $pat ): ?>class="thrive-selected-pattern"<?php endif ?>></a>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		</label>
		<script type="text/javascript">

			jQuery(document).ready(function () {
				var firstPattern = jQuery('.patternList').find('li a').first().css('background-image');

				if (jQuery('.thrive-selected-pattern').length > 0) {
					firstPattern = jQuery('.thrive-selected-pattern').css('background-image');
				}


				jQuery('.defaultPattern span').css('background-image', firstPattern);
				jQuery('.patternList li a').each(function () {
					jQuery(this).click(function () {
						var imageSource = jQuery(this).css('background-image');
						jQuery('.defaultPattern span').css('background-image', imageSource);
						jQuery('.patternList').hide();
						jQuery("#thrive_select_customizer_pattern").val(jQuery(this).attr('id'));
						jQuery("#thrive_select_customizer_pattern").triggerHandler('change');
						return false;
					});
				});
				jQuery('#showPattern').click(function () {
					jQuery('.patternList').toggle();
					return false;
				});
			});

		</script>
		<?php
	}

}

?>
