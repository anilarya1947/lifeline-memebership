<div id="fb-root"></div>
<script>(function (d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id))
			return;
		js = d.createElement(s);
		js.id = id;
		js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
		fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>

<img src="<?php echo get_template_directory_uri(); ?>/inc/images/TT-logo-small.png"
     class="thrive_admin_logo"/>
<div class="share-thrive">
	<img src="<?php echo get_template_directory_uri(); ?>/inc/images/share-thrive.png" class="thrive_admin_share left"/>
	<div class="left">
		<div class="fb-share-button" data-href="http://thrivethemes.com/" data-width="80"
		     data-layout="button_count"></div>
		<div class="thrive-plus-one">
			<div class="g-plusone" data-size="medium" data-href="http://thrivethemes.com/"></div>
		</div>
		<a href="https://twitter.com/share" class="twitter-share-button" data-url="http://thrivethemes.com"
		   data-text="WordPress themes for startups and business builders" data-related="ThriveThemes">Tweet</a>
	</div>
	<div class="clear"></div>
</div>