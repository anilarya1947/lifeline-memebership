<table>
	<tr>
		<td>Full Screen Preview</td>
		<td>Mobile Screen Preview</td>
	</tr>
	<tr class="phone_background_set">
		<td>
			<div class="phone">
				<div class="phr">
					<span><?php echo $preview_params['header_phone_text']; ?></span>
					<a href="tel:<?php echo $preview_params['header_phone_no']; ?>"><?php echo $preview_params['header_phone_no']; ?></a>
				</div>
			</div>
		</td>
		<td>
			<div class="phone_mobile <?php echo $preview_params['header_phone_btn_color'] ?>">
				<div class="phr">
					<span class="mphr"><?php echo $preview_params['header_phone_text_mobile']; ?></span>
					<a href="tel:<?php echo $preview_params['header_phone_no']; ?>"><?php echo $preview_params['header_phone_no']; ?></a>
				</div>
			</div>
		</td>
	</tr>
</table>



