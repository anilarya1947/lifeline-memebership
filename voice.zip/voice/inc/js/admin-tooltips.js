jQuery(document).ready(function () {
    jQuery('.tooltips').powerTip({
        placement: 'n', mouseOnToPopup: true
    });
});