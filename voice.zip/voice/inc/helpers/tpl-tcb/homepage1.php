<div class="thrv_wrapper thrv_page_section" data-tve-style="1" style="margin-top: -50px;">
	<div class="pswr out" style="background-color: #EAEAEA">
		<div class="in pddbg lightSec pdfbg" data-width="1920" data-height="800"
		     style="max-width: 1903px; -webkit-box-shadow: none; box-shadow: none; box-sizing: border-box; min-height: 792px; background-image: url('<?php echo $images_dir; ?>/urban_bridge.jpg');">
			<div class="cck tve_clearfix"><h1 class="">Lorem Ipsum Dolor Sit Amet</h1>

				<div class="thrv_wrapper thrv_columns">
					<div class="tve_colm tve_twc"><p class="">Nunc tincidunt diam in massa rhoncus condimentum. Etiam
							suscipit enim vitae purus fringilla venenatis. Phasellus rhoncus, turpis eget tempus
							tincidunt, erat mi porta purus.</p>

						<div class="tve_wp_shortcode thrv_wrapper">
							<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[thrive_link
								color=\"orange\" link=\"#\" target=\"_self\" size=\"big\" align=\"aligncenter\"]Sign Up
								Today![/thrive_link]__TVE_SHORTCODE_RAW___
							</div>
						</div>
					</div>
					<div class="tve_colm tve_twc tve_lst"></div>
				</div>
			</div>
		</div>
	</div>
</div><h2 class=""></h2><h2 class="tve_p_center"> Our Services </h2>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[divider
		style=\"dark\"]__TVE_SHORTCODE_RAW___
	</div>
</div>
<div class="csc">
	<div class="colm thc">
		<div class="thrivecb blue">
			<div class="shn"><p class=""><img class="aligncenter size-full wp-image-418" alt="icon1"
			                                  src="<?php echo $images_dir; ?>/icon1.png" width="78" height="68"></p>

				<p style="text-align: center;" class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit.
					Pellentesque pharetra facilisis sem sed rhoncus. Nullam varius arcu non ante mattis, et ultricies
					nulla volutpat.</p></div>
		</div>
	</div>
	<div class="colm thc">
		<div class="thrivecb green">
			<div class="shn"><p class=""><img class="aligncenter size-full wp-image-419" alt="icon2"
			                                  src="<?php echo $images_dir; ?>/icon2.png" width="78" height="68"></p>

				<p style="text-align: center;" class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit.
					Pellentesque pharetra facilisis sem sed rhoncus. Nullam varius arcu non ante mattis, et ultricies
					nulla volutpat. </p></div>
		</div>
	</div>
	<div class="colm thc lst">
		<div class="thrivecb orange">
			<div class="shn"><p class=""><img class="aligncenter size-full wp-image-420" alt="icon3"
			                                  src="<?php echo $images_dir; ?>/icon3.png" width="78" height="68"></p>

				<p style="text-align: center;" class="">Lorem ipsum dolor sit amet, consectetur adipiscing elit.
					Pellentesque pharetra facilisis sem sed rhoncus. Nullam varius arcu non ante mattis, et ultricies
					nulla volutpat.</p></div>
		</div>
	</div>
	<div class="clear"></div>
</div> <h2 style="text-align: center;" class="">Another Sub-Heading</h2>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[divider
		style=\"dark\"]__TVE_SHORTCODE_RAW___
	</div>
</div> <p style="text-align: center;" class="">Proin pulvinar, justo eget tristique dictum, sapien tellus pharetra quam,
	et rutrum odio diam non odio. Duis eu dui id enim sagittis tempus in id dolor. Sed gravida metus nec dignissim
	egestas. Phasellus congue purus eget eros volutpat sagittis. Sed eu augue consequat, pharetra nunc non, bibendum
	lectus.</p><p data-default="Enter your text here..."
                  class="tve_p_center"></p><h2 class="tve_p_center"> The Latest
	From Our Blog </h2><p></p>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[divider
		style=\"dark\"]__TVE_SHORTCODE_RAW___
	</div>
</div>
<div class="thrv_wrapper thrv_post_grid">
	<div class="thrive-shortcode-config" style="display: none !important">
		__CONFIG_post_grid__<?php echo $config_post_grid; ?>__CONFIG_post_grid__
	</div>
</div>
<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="2">
	<div style="background-color:white" class="tve_cb tve_cb2 tve_blue">
		<div class="tve_cb_cnt">
			<h2 class="tve_p_center rft" style="font-size: 46px;"><font color="#525252">
					Never Miss a New Post! Join Our Newsletter:</font></h2>
		</div>
		<div class="tve_cb_cnt">
			<div class="thrv_wrapper thrv_thrive_optin" data-tve-style="1">
				<div class="thrive-shortcode-config" style="display: none !important">
					__CONFIG_optin__{"optin":<?php echo $optin_id; ?>
					,"color":"green","size":"vertical","text":"Subscribe Now","layout":"horizontal"}__CONFIG_optin__
				</div>
			</div>
		</div>
	</div>
</div>
