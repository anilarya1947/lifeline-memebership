<h1 class="tve_p_center"><strong>Congratulations for Signing Up!</strong></h1>
<h3 class="tve_p_center"> Here are your IMPORTANT next steps: </h3>
<p data-default="Enter your text here..." class="tve_p_center">To make sure we got the right email address, we need you
	to click on a confirmation link in an email we just sent to you.</p>
<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_oth">
		<div class="tve_wp_shortcode thrv_wrapper">
			<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[thrive_text_block color=\'blue\'
				headline=\'Step 1:\']Go to your <strong>email inbox</strong> (of the email address you signed up
				with).[/thrive_text_block]__TVE_SHORTCODE_RAW___
			</div>
		</div>
	</div>
	<div class="tve_colm tve_oth">
		<div class="tve_wp_shortcode thrv_wrapper">
			<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__<p>[thrive_text_block
					color=\'blue\' headline=\'Step 2:\']Find the email sent by <strong>YourFromNameHere</strong>, with
					the subject line: <strong>Your Subject Line Here</strong>.[/thrive_text_block]</p>
				__TVE_SHORTCODE_RAW___
			</div>
		</div>
	</div>
	<div class="tve_colm tve_thc tve_lst">
		<div class="tve_wp_shortcode thrv_wrapper">
			<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__<p>[thrive_text_block
					color=\'blue\' headline=\'Step 3:\']Open this email and <strong>click on the link inside</strong>.
					That\'s it! The process will then complete automatically.[/thrive_text_block]</p>
				__TVE_SHORTCODE_RAW___
			</div>
		</div>
	</div>
</div><p class="">Once you’ve completed the confirmation steps, you will get immediate access to the free report/the
	bonuses/the exclusive content/whatever you signed up for!</p>
