<div class="thrv_wrapper thrv_page_section" data-tve-style="1" style="margin-top: -40px;">
	<div class="out" style="background-color: #2d4e92">
		<div class="in lightSec">
			<div class="cck tve_clearfix"><h1 class=""></h1>

				<h1 class="tve_p_center"> This is Where You Put a <strong>Big Headline</strong>. Make Your Visitors
					<strong>Want</strong> to Know More… </h1>


				<h3 class="tve_p_center"> And don’t forget how useful a well-written sub-heading can be. </h3> <span
					class="tve_image_frame">
                    <img class="tve_image" alt="" src="<?php echo $images_dir; ?>/video-placeholder-800.png"
                         style="width: 1920px"> </span></div>
			<div class="cck tve_clearfix">
				<div class="tve_wp_shortcode thrv_wrapper">
					<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__ [thrive_link
						color="green" link="#" target="_self" size="big" align="aligncenter"]Click Here to Start Your
						Free Trial[/thrive_link]__TVE_SHORTCODE_RAW___
					</div>
				</div>
			</div>
		</div>
	</div>
</div><p data-default="Enter your text here..." class="" style="margin-top: 20px !important;">A simple paragraph,
	leading with the main benefit of your product and the main reason your visitors should consider buying it. Lorem
	ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dapibus diam non mollis vestibulum. Cras rhoncus
	urna metus, in hendrerit neque vestibulum quis.</p>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[divider]__TVE_SHORTCODE_RAW___</div>
</div> <h2 style="text-align: center;" class="">How You'll Benefit From This Product:</h2>
<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_foc">
		<img class="aligncenter size-full wp-image-479" alt="icon4" src="<?php echo $images_dir; ?>/icon4.png"
		     width="55" height="48">

		<p style="text-align: center;" class=""><strong>Lorem Ipsum Dolor</strong></p>

		<p style="text-align: center;" class="">Sit amet, consectetur adipiscing elit. Pellentesque dapibus diam non
			mollis vestibulum. Cras rhoncus urna metus, in hendrerit neque vestibulum quis.</p></div>
	<div class="tve_colm tve_foc"><img class="aligncenter size-full wp-image-480" alt="icon5"
	                                   src="<?php echo $images_dir; ?>/icon5.png" width="64" height="48">

		<p style="text-align: center;" class=""><strong>Ut Tellus Odio Ultricies</strong></p>

		<p style="text-align: center;" class="">A vehicula ut, fermentum in neque. Nullam pharetra pretium vestibulum.
			Pellentesque porta venenatis velit, vel dapibus neque dapibus quis.</p></div>
	<div class="tve_colm tve_foc"><img class="aligncenter size-full wp-image-482" alt="icon6"
	                                   src="<?php echo $images_dir; ?>/icon6.png" width="42" height="48">

		<p style="text-align: center;" class=""><strong>Nunc Lobortis Sed</strong></p>

		<p style="text-align: center;" class="">Sapien ut tristique. Fusce luctus imperdiet tempus. Phasellus a tortor
			aliquet leo at, tristique tellus. Quisque at condimentum elit.</p></div>
	<div class="tve_colm tve_foc tve_lst">
		<img class="aligncenter size-full wp-image-483" alt="icon7" src="<?php echo $images_dir; ?>/icon7.png"
		     width="55" height="48">

		<p style="text-align: center;" class=""><strong>Nam Malesuada Lectus</strong></p>

		<p style="text-align: center;" class="">Id feugiat facilisis, est leo congue dolor, quis auctor enim arcu non
			sem. Vivamus gravida lacinia interdum. Curabitur malesuada lacus.</p></div>
</div>
<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_foc"><img class="aligncenter size-full wp-image-485" alt="icon8"
	                                   src="<?php echo $images_dir; ?>/icon8.png" width="50" height="48">

		<p style="text-align: center;" class=""><strong>Nunc Lobortis Sed</strong></p>

		<p style="text-align: center;" class="">Sapien ut tristique. Fusce luctus imperdiet tempus. Phasellus a tortor
			aliquet leo at, tristique tellus. Quisque at condimentum elit.</p></div>
	<div class="tve_colm tve_foc"><img class="aligncenter size-full wp-image-486" alt="icon9"
	                                   src="<?php echo $images_dir; ?>/icon9.png" width="48" height="48">

		<p style="text-align: center;" class=""><strong>Lorem Ipsum Dolor</strong></p>

		<p style="text-align: center;" class="">Sit amet, consectetur adipiscing elit. Pellentesque dapibus diam non
			mollis vestibulum. Cras rhoncus urna metus, in hendrerit neque vestibulum quis.</p></div>
	<div class="tve_colm tve_foc"><img class="aligncenter size-full wp-image-487" alt="icon10"
	                                   src="<?php echo $images_dir; ?>/icon10.png" width="48" height="48">

		<p style="text-align: center;" class=""><strong>Ut Tellus Odio Ultricies</strong></p>

		<p style="text-align: center;" class="">A vehicula ut, fermentum in neque. Nullam pharetra pretium vestibulum.
			Pellentesque porta venenatis velit, vel dapibus neque dapibus quis.</p></div>
	<div class="tve_colm tve_foc tve_lst"><img class="aligncenter size-full wp-image-488" alt="icon11"
	                                           src="<?php echo $images_dir; ?>/icon11.png" width="48" height="48">

		<p style="text-align: center;" class=""><strong>Nunc Lobortis Sed</strong></p>

		<p style="text-align: center;" class="">Sapien ut tristique. Fusce luctus imperdiet tempus. Phasellus a tortor
			aliquet leo at, tristique tellus. Quisque at condimentum elit.</p></div>
</div>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[divider]__TVE_SHORTCODE_RAW___</div>
</div> <h2 style="text-align: center;" class="">A New Sub-Heading, to Lead Into the Next Part:</h2> <p class="">Lorem
	ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tincidunt lacinia vehicula. Aenean pretium dui ac sem
	ultricies, ut rutrum purus dapibus. Vivamus blandit ornare elit sodales eleifend.</p>
<img class="aligncenter size-full wp-image-491" alt="icon-set" src="<?php echo $images_dir; ?>/icon-set.png" width="785"
     height="207">
<p class=""> Use images and illustrations frequently, to avoid a wall-of-text impression on your page.
	<strong>Whenever possible, illustrate the benefits of your product. in other words: show, don"t just tell.</strong>
</p> <p class=""> Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor felis ut urna
	adipiscing, id condimentum quam auctor. Donec eleifend sit amet ligula sed blandit. Fusce lacinia, dui nec pharetra
	scelerisque, massa dui aliquam leo, venenatis ultrices sem velit non augue. Integer non volutpat mi, quis molestie
	diam. Quisque sit amet commodo nibh, id iaculis arcu. Mauris quis quam imperdiet, laoreet nisi non, posuere urna.
	Donec ut metus risus.</p>
<div class="thrv_wrapper thrv_page_section" data-tve-style="1">
	<div class="out" style="background-color: #2d4e92">
		<div class="in lightSec">
			<div class="cck tve_clearfix"><h2 style="text-align: center;" class="">What Our Customers Are Saying:</h2>

				<div class="tve_wp_shortcode thrv_wrapper">
					<div class="tve_shortcode_raw" style="display: none">
						___TVE_SHORTCODE_RAW__[one_half_first][thrive_testimonial name="ExampleGuy" company="Editor at
						ExampleSite" image="<?php echo $images_dir; ?>/testimonial-pic.jpg"]"Pellentesque ut nunc sit
						amet mi vestibulum tincidunt sit amet vel leo. Phasellus et dolor at velit molestie blandit. In
						a justo sit amet erat pretium rutrum sed at metus. In vitae arcu magna. Morbi vel fermentum
						ligula."[/thrive_testimonial][/one_half_first][one_half_last][thrive_testimonial name="Happy
						Customer" company="" image=""]"Mauris cursus erat eget elit hendrerit, sed posuere elit
						vestibulum. Curabitur porttitor felis ut urna adipiscing, id condimentum quam auctor. Donec
						eleifend sit amet ligula sed blandit. Fusce lacinia, dui nec pharetra
						scelerisque."[/thrive_testimonial][/one_half_last] [one_half_first][thrive_testimonial
						name="Another Customer" company="" image=""]"Vestibulum eget sollicitudin arcu, non fringilla
						neque. Phasellus sodales augue id massa tempus, ut ultricies justo lacinia. Nunc a neque
						vestibulum, aliquet justo eget, lacinia augue. Donec lacinia, est vitae fringilla luctus, augue
						est sollicitudin nulla, id laoreet arcu sapien quis
						diam."[/thrive_testimonial][/one_half_first][one_half_last][thrive_testimonial name="Testimonial
						Gal" company="" image=""]"Cras vel nulla non felis eleifend volutpat. Donec sodales convallis
						turpis, vel pharetra justo. Curabitur porta justo ac odio sagittis, in pharetra sapien vehicula.
						Donec sed ipsum magna. Nam vel aliquam odio, lacinia lacinia
						turpis."[/thrive_testimonial][/one_half_last]__TVE_SHORTCODE_RAW___
					</div>
				</div>
			</div>
		</div>
	</div>
</div> <h2 style="text-align: center;" class="">Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing</h2> <p class="">
	Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor felis ut urna adipiscing,
	id condimentum quam auctor. Donec eleifend sit amet ligula sed blandit. Fusce lacinia, dui nec pharetra scelerisque,
	massa dui aliquam leo, venenatis ultrices sem velit non augue.</p>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__ [thrive_text_block color="note"
		headline=""] <h3>What You'll Get When You Sign Up Today:
			<img class="alignright wp-image-226" alt="cover-image-1b"
			     src="<?php echo $images_dir; ?>/cover-image-1b.png" width="232" height="270"></h3>
		<ul>
			<li>Donec lacinia, est vitae fringilla luctus.</li>
			<li><strong>Augue est sollicitudin nulla, id laoreet arcu sapien quis diam.</strong></li>
			<li>Morbi sed nunc magna.</li>
			<li><strong>Vestibulum ante ipsum primis in faucibus.</strong></li>
			<li>Orci luctus et ultrices posuere cubilia.</li>
			<li><strong>Curae; Vivamus orci dui, laoreet et.</strong></li>
			<li>Dui ut, dapibus venenatis ipsum.</li>
		</ul>
		[/thrive_text_block]__TVE_SHORTCODE_RAW___
	</div>
</div>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[divider]__TVE_SHORTCODE_RAW___</div>
</div> <h2 style="text-align: center;" class="">Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing</h2> <p class="">
	Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor felis ut urna adipiscing,
	id condimentum quam auctor. Donec eleifend sit amet ligula sed blandit. Fusce lacinia, dui nec pharetra scelerisque,
	massa dui aliquam leo, venenatis ultrices sem velit non augue.</p> <p class=""> Vestibulum eget sollicitudin arcu,
	non fringilla neque. Phasellus sodales augue id massa tempus, ut ultricies justo lacinia. Nunc a neque vestibulum,
	aliquet justo eget, lacinia augue. Donec lacinia, est vitae fringilla luctus, augue est sollicitudin nulla, id
	laoreet arcu sapien quis diam. </p>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[divider]__TVE_SHORTCODE_RAW___</div>
</div>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[one_third_first][thrive_text_block
		color="light" headline=""] <h3 style="text-align: center;">Silver</h3>
		<p style="text-align: center;">Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur
			porttitor felis ut urna adipiscing.</p>

		<p style="text-align: center;"><strong>$12/month</strong></p> [thrive_link color="orange" link="#"
		target="_self" size="medium" align="aligncenter"]Add to
		Cart[/thrive_link][/thrive_text_block][/one_third_first][one_third][thrive_text_block color="light" headline=""]
		<h3 style="text-align: center;">Gold</h3>

		<p style="text-align: center;">Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur
			porttitor felis ut urna adipiscing.</p>

		<p style="text-align: center;"><strong>$30/month</strong></p>
		[thrive_link color="orange" link="#" target="_self" size="medium" align="aligncenter"]Add to
		Cart[/thrive_link][/thrive_text_block][/one_third][one_third_last][thrive_text_block color="light" headline=""]
		<h3 style="text-align: center;">Platinum</h3>

		<p style="text-align: center;">Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur
			porttitor felis ut urna adipiscing.</p>

		<p style="text-align: center;"><strong>$90/month</strong></p> [thrive_link color="orange" link="#"
		target="_self" size="medium" align="aligncenter"]Add to Cart[/thrive_link]
		[/thrive_text_block][/one_third_last]__TVE_SHORTCODE_RAW___
	</div>
</div> <p style="text-align: center;" class=""><em>All plans include our free installation service.</em></p>
<div class="thrv_wrapper thrv_page_section" data-tve-style="1">
	<div class="out" style="background-color: #2d4e92">
		<div class="in lightSec">
			<div class="cck tve_clearfix"><h2 style="text-align: center;" class="">100% Satisfaction Guarantee</h2>

				<p style="text-align: center;" class="">You have a full 30 days to test our product. If you aren\'t
					completely satisfied with the service you receive, just ask and we will gladly give you a full
					refund on your purchase price. Give it a try, the risk is on us!</p></div>
		</div>
	</div>
</div>