<h1 class="tve_p_center"> Sign Up to Get Your Free Report/Product/Download! </h1><h3 class="tve_p_center"> Subheading
	emphasizes how cool your free thing is. </h3>
<div class="thrv_wrapper thrv_columns">
	<div class="tve_colm tve_twc"><p class=""></p>

		<p class=""> The time to make a change is now! </p>

		<p class=""> Download our free report/product/whatever, to get the following benefits: </p>
		<ul class="">
			<li class=""><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</strong></li>
			<li class=""> Donec mollis, dolor et consectetur hendrerit.</li>
			<li class=""><strong>Metus nisl interdum felis, nec venenatis eros ligula convallis ligula.</strong></li>
			<li class=""> Cras dapibus orci urna, in sagittis justo rutrum non.</li>
			<li class=""><strong>Ut consequat lectus a elementum convallis.</strong></li>
			<li class=""> Fusce sodales metus ut massa vehicula.</li>
		</ul>
		<p class=""> All this and more is yours for FREE! </p>

		<p class=""></p></div>
	<div class="tve_colm tve_twc tve_lst">
		<div style="width: 1920px" class="thrv_wrapper tve_image_caption"><span class="tve_image_frame"> <img
					class="tve_image" alt="" src="<?php echo $images_dir; ?>/cover-image-1b.png" style="width: 1920px"> </span>
		</div>
	</div>
</div>
<div class="thrv_wrapper thrv_page_section" data-tve-style="1">
	<div class="out" style="background-color: rgba(44, 44, 44, 1);">
		<div class="in lightSec">
			<div class="cck tve_clearfix">
				<h2 class=""></h2>

				<h2 class="tve_p_center">
					Just Enter Your Name and Email Address Below<br> to Instantly Receive Your Report:
				</h2>

				<div class="thrv_wrapper thrv_thrive_optin" data-tve-style="1">
					<div class="thrive-shortcode-config" style="display: none !important">
						__CONFIG_optin__{"optin": <?php echo $optin_id; ?>
						,"color":"orange","size":"vertical","text":"Get Instant
						Access!","layout":"horizontal"}__CONFIG_optin__
					</div>

				</div>
			</div>
		</div>
	</div>
</div>