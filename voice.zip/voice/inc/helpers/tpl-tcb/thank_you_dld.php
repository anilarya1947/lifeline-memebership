<h1 style="text-align: center;" class="">Thank You for Signing Up!</h1> <p style="text-align: center;" class="">Here\'s
	your free report/e-book/software/download:</p>
<div style="width: 386px" class="thrv_wrapper tve_image_caption aligncenter"><span class="tve_image_frame"> <img
			class="tve_image" alt="" src="<?php echo $images_dir; ?>/cover-image-1b.png" style="width: 386px"> </span>
</div><p style="text-align: center; margin-bottom: 0px ! important;" class=""><a class=""
                                                                                 href="http://192.168.1.191/wordpress/thank-you-page-12/#">Right
		click and select ‘Save link as…’ </a><br></p><p style="text-align: center; color: rgb(230, 14, 14);" class=""><a
		href="#">‘</a>Save target as…’ to download this file.</p>  <p class=""> If you have any questions about the
	report or would like to share your thoughts about it, you can always get in touch with us here: <a href="#">link to
		contact page.</a></p>
<div class="thrv_wrapper thrv_contentbox_shortcode" data-tve-style="2">
	<div style="background-color: rgba(255, 251, 201, 1)" class="tve_cb tve_cb2 tve_red">
		<div class="tve_cb_cnt">
			<h3 style="font-size: 33px;" class="rft"><font color="#525252">
					Did You Know…
				</font>
			</h3>
		</div>
		<hr style="background-color: rgba(255, 251, 201, 1)">
		<div class="tve_cb_cnt">
			<p style="color: rgb(82, 82, 82);" class="">We also have a premium product/premium membership/offer coaching
				or consulting? (Use this space to advertise a premium service or product. Don’t push hard, at this
				point, but use the opportunity to make sure your new subscribers are aware of your products or
				services.)</p>
		</div>
	</div>
</div>