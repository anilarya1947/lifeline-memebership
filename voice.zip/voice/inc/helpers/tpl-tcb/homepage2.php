<h1 class=""> This is Your Big, <span style="color: #4174dc;"> <strong>Bold Headline</strong> </span> <br> to Grab
	Attention. </h1>
<div class="thrv_wrapper thrv_page_section" data-tve-style="1">
	<div class="pswr out" style="background-color: #EAEAEA">
		<div class="in pddbg lightSec pdwbg"
		     style="box-sizing: border-box; max-width: 1903px; -webkit-box-shadow: none; box-shadow: none; background-image: url('<?php echo $images_dir; ?>/urban_building.jpg');">
			<div class="cck tve_clearfix"><p style="text-align: right; margin-bottom: 12em;" class="">Lorem ipsum dolor
					sit amet, consectetur adipiscing elit. Sed non euismod elit, et tempor augue.</p></div>
		</div>
	</div>
</div> <h3 style="text-align: center;" class="">Lorem Ipsum Dolor Sit Amet</h3> <p style="text-align: center;" class="">
	Mauris venenatis ac nulla nec pharetra. Nam interdum lectus diam, ac pulvinar velit vehicula ut. Duis a vulputate
	tellus. Sed mattis justo diam, non vehicula orci auctor rutrum.</p>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[divider
		style="dark"]__TVE_SHORTCODE_RAW___
	</div>
</div>
<div class="thrv_wrapper thrv_columns tve_clearfix">
	<div class="tve_colm tve_oth"><p class=""><img class="aligncenter size-full wp-image-433" alt="icon1b"
	                                               src="<?php echo $images_dir; ?>/icon1b.png" width="78" height="68">
		</p><h4 style="text-align: center;" class="">Lorem Ipsum</h4>

		<p style="text-align: center;" class="">Praesent tortor nibh, faucibus at purus nec, tincidunt condimentum
			ligula. Sed lobortis laoreet lorem, nec fermentum enim suscipit non.</p>

		<p style="text-align: center;" class="">​</p></div>
	<div class="tve_colm tve_oth"><p class=""><img class="aligncenter size-full wp-image-434" alt="icon2b"
	                                               src="<?php echo $images_dir; ?>/icon2b.png" width="78" height="68">
		</p> <h4 style="text-align: center;" class="">Dolor Sit Amet</h4>

		<p style="text-align: center;" class="">Phasellus est lacus, congue sodales urna tristique, vehicula vulputate
			ligula. Phasellus leo dui, adipiscing eu mollis sed, rhoncus vel sapien.</p>

		<p class="">​</p></div>
	<div class="tve_colm tve_thc tve_lst"><p class=""><img class="aligncenter size-full wp-image-435" alt="icon3b"
	                                                       src="<?php echo $images_dir; ?>/icon3b.png" width="78"
	                                                       height="68"></p><h4 style="text-align: center;" class="">
			Consectetur Adipiscing</h4>

		<p style="text-align: center;" class="">Mauris venenatis ac nulla nec pharetra. Nam interdum lectus diam, ac
			pulvinar velit vehicula ut. Duis a vulputate tellus. Sed mattis justo diam.</p>

		<p class="">​</p></div>
</div>
<div class="thrv_wrapper thrv_page_section" data-tve-style="1">
	<div class="out" style="background-color: #EAEAEA">
		<div class="in darkSec">
			<div class="cck tve_clearfix">

				<h2 class="tve_p_center">
					Our Recent Contributions
				</h2>

				<div class="thrv_wrapper thrv_post_grid">
					<div class="thrive-shortcode-config" style="display: none !important">
						__CONFIG_post_grid__<?php echo $config_post_grid; ?>__CONFIG_post_grid__
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="thrv_wrapper thrv_page_section" data-tve-style="1">
	<div class="pswr out" style="background-color: #EAEAEA">
		<div class="in darkSec pddbg"
		     style="box-sizing: border-box; max-width: 1903px; -webkit-box-shadow: none; box-shadow: none; background-image: url('<?php echo $images_dir; ?>/urban_building.jpg');">
			<div class="cck tve_clearfix"><h2 class="tve_p_center" style="color: rgb(244, 244, 244);">Our Clients</h2>

				<div class="thrv_wrapper thrv_columns tve_clearfix">
					<div class="tve_colm tve_thc tve_lst"><img class="aligncenter size-full wp-image-438"
					                                           alt="fastforward-white-2"
					                                           src="<?php echo $images_dir; ?>/fastforward-white-2.png"
					                                           width="400" height="140"></div>
					<div class="tve_colm tve_oth"><img class="aligncenter size-full wp-image-438"
					                                   alt="fastforward-white-2"
					                                   src="<?php echo $images_dir; ?>/morning-star-white-2.png"
					                                   width="400" height="140"></div>
					<div class="tve_colm tve_oth"><img class="aligncenter size-full wp-image-440"
					                                   alt="morning-star-white-2"
					                                   src="<?php echo $images_dir; ?>/wastingtime-white-2.png"
					                                   width="400" height="140"></div>
				</div>
			</div>
		</div>
	</div>
</div> <h3 style="text-align: center;" class="">Praesent at Leo Pellentesque</h3> <p style="text-align: center;"
                                                                                     class="">Cras interdum et justo sed
	posuere. In hac habitasse platea dictumst. Quisque pharetra, purus quis viverra aliquet, sem libero congue lectus,
	nec consequat justo mi tempus felis. Curabitur ut tempor augue. Phasellus venenatis venenatis pellentesque. Aliquam
	erat volutpat.</p>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[thrive_link color="blue" link="#"
		target="_self" size="medium" align="aligncenter"]Get a Quote[/thrive_link]__TVE_SHORTCODE_RAW___
	</div>
</div>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[page_section color="#ededed"
		textstyle="dark" position="bottom" padding_top="on"][thrive_follow_me facebook="http://facebook.com/imimpact"
		twitter="shanerqr" linkedin="555"][/page_section]__TVE_SHORTCODE_RAW___
	</div>
</div>