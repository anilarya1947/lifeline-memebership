<div class="thrv_wrapper thrv_page_section" data-tve-style="1" style="margin-top: -50px;">
	<div class="pswr out" style="background-color: #EAEAEA">
		<div class="in pddbg lightSec" data-width="1000" data-height="578"
		     style="box-sizing: border-box; max-width: 1903px; -webkit-box-shadow: none; box-shadow: none; background-image: url('<?php echo $images_dir; ?>/blurred-bg-1.jpg');">
			<div class="cck tve_clearfix"><h1 style="text-align: center;" class=""><strong>Attention-Grabbing Headline
						Goes Here!</strong></h1>

				<div class="thrv_wrapper thrv_columns tve_clearfix">
					<div class="tve_colm tve_tth">
						<div style="width: 640px" class="thrv_wrapper tve_image_caption"><span
								class="tve_image_frame"><img class="tve_image" alt=""
						                                     src="<?php echo $images_dir; ?>/video-placeholder-800.png"
						                                     style="width: 640px"></span></div>
					</div>
					<div class="tve_colm tve_oth tve_lst"><p class="">​</p>

						<h3 class="">Sub-Heading Goes Here!</h3>

						<p class="">Sign up below to receive instant access to {Title of Your Free Product Here}.</p>

						<p class="">Enter your name and email address below to get started right away!</p>

						<div class="thrv_wrapper thrv_thrive_optin" data-tve-style="1">
							<div class="thrive-shortcode-config" style="display: none !important">
								__CONFIG_optin__{"optin": <?php echo $optin_id; ?>
								,"color":"blue","size":"vertical","text":"Subscribe
								Now","layout":"vertical"}__CONFIG_optin__
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[thrive_testimonial name="Example Guy"
		image="<?php echo $images_dir; ?>/testimonial-pic.jpg" style="dark"]A positive testimonial from one or several
		of your users can boost conversions. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce consectetur
		sem quis metus tempusrhoncus.[/thrive_testimonial]__TVE_SHORTCODE_RAW___
	</div>
</div>
<div class="tve_wp_shortcode thrv_wrapper">
	<div class="tve_shortcode_raw" style="display: none">___TVE_SHORTCODE_RAW__[thrive_testimonial name="Other Guy"
		company="" image="" style="dark"]Sed scelerisque enim ut justo tempus, id luctus odio aliquet. Vestibulum nec
		dapibus neque. Ut ultrices, nisl vel fermentum tristique, dui enim tempor lacus, id condimentum metus ante vel
		augue. Aliquam pulvinar quam vel augue vestibulum euismod. Nunc blandit mollisorci,
		vitae pellentesque nulla eleifend a.[/thrive_testimonial]__TVE_SHORTCODE_RAW___
	</div>
</div>