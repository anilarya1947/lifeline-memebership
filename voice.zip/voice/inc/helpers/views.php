<?php

function _thrive_get_sidebar_element_class( $options = null ) {
	if ( ! $options ) {
		$options = thrive_get_theme_options();
	}

	if ( $options['sidebar_alignement'] != 'color' && $options['sidebar_alignement'] != 'image' && $options['sidebar_alignement'] != 'featured' ) {
		return "sdef";
	}

	if ( $options['sidebar_alignement'] == 'color' ) {
		return "scol";
	}

	if ( $options['sidebar_alignement'] == 'image' ) {
		return "sdib";
	}

	if ( $options['sidebar_alignement'] == 'featured' ) {
		if ( ! is_single() && ! is_page() ) {
			return "sdef";
		}

		return "sdfb";
	}
}

function _thrive_get_sidebar_bg_element( $options = null ) {
	if ( ! $options ) {
		$options = thrive_get_theme_options();
	}

	if ( $options['sidebar_alignement'] != 'color' && $options['sidebar_alignement'] != 'image' && $options['sidebar_alignement'] != 'featured' ) {
		return '<div class="sAsdmy"></div>';
	}

	if ( $options['sidebar_alignement'] == 'color' ) {
		return '<div class="sAsdmy" style="background-color: ' . $options['sidebar_style_value'] . '"></div>';
	}

	if ( $options['sidebar_alignement'] == 'image' ) {
		return "<div class='sAsdmy' style=\"background-image: url('" . $options['sidebar_style_value'] . "')\"></div>";
	}

	if ( $options['sidebar_alignement'] == 'featured' ) {
		if ( ! is_single() && ! is_page() ) {
			return '<div class="sAsdmy"></div>';
		}
		$featured_image = null;
		if ( has_post_thumbnail( get_the_ID() ) ) {
			$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), "wide" );
		}
		if ( $featured_image && isset( $featured_image[0] ) ) {
			return "<div class='sAsdmy' style=\"background-image: url('" . $featured_image[0] . "')\"></div>";
		} else {
			return '<div class="sAsdmy"></div>';
		}
	}

	return '<div class="sAsdmy"></div>';
}

function _thrive_get_sidebar_author_info( $options = null ) {
	if ( ! $options ) {
		$options = thrive_get_theme_options();
	}

	if ( is_single() || is_page() || is_front_page() ) {
		global $post;
		$author_id = $post->post_author;
	} elseif ( is_author() ) {
		$author_id = get_the_author_meta( 'ID' );
	} else {
		if ( empty( $author_id ) ) {
			return false;
		}
	}

	$user_info = get_userdata( $author_id );
	if ( ! $user_info ) {
		return false;
	}
	$social_links = ( array(
		"twitter"  => get_the_author_meta( 'twitter', $author_id ),
		"fb"       => get_the_author_meta( 'facebook', $author_id ),
		"g_plus"   => get_the_author_meta( 'gplus', $author_id ),
		"linkedin" => get_the_author_meta( 'linkedin', $author_id ),
		"xi"       => get_the_author_meta( 'xing', $author_id )
	) );


	$show_social_profiles = explode( ',', get_the_author_meta( 'show_social_profiles', $author_id ) );
	$show_social_profiles = array_filter( $show_social_profiles );
	if ( empty( $show_social_profiles ) ) { // back-compatibility
		$show_social_profiles = array( 'e', 'fb', 'twitter', 'g_plus' );
	}
	$author_website_text = get_the_author_meta( 'thrive_author_website_text', $author_id );
	if ( empty( $author_website_text ) ) {
		$author_website_text = __( "Read the full story here", 'thrive' );
	}

	$author_id = $options['sidebar_author_value'];
	if ( ! is_numeric( $author_id ) && ! empty( $author_id ) ) {
		return array( 'static_pic' => $author_id,
		              'avatar'               => get_avatar( $user_info->user_email, 125 ),
		              'display_name'         => $user_info->display_name,
		              'description'          => $user_info->description,
		              'social_links'         => $social_links,
		              'show_social_profiles' => $show_social_profiles,
		              'posts_url'            => get_author_posts_url( $author_id ),
		              'author_website'       => get_the_author_meta( 'thrive_author_website', $author_id ),
		              'author_website_text'  => $author_website_text
			);
	}


	//overwrite only if we have a user set in options
	if ( is_numeric( $options['sidebar_author_value'] ) && ! empty( $options['sidebar_author_value'] ) ) {
		$author_id = $options['sidebar_author_value'];
	}

	return array(
		'avatar'               => get_avatar( $user_info->user_email, 125 ),
		'display_name'         => $user_info->display_name,
		'description'          => $user_info->description,
		'social_links'         => $social_links,
		'show_social_profiles' => $show_social_profiles,
		'posts_url'            => get_author_posts_url( $author_id ),
		'author_website'       => get_the_author_meta( 'thrive_author_website', $author_id ),
		'author_website_text'  => $author_website_text
	);
}

function _thrive_is_supported_format( $format ) {
	$supported_formats = array( "audio", "image", "gallery", "quote", "video" );

	return in_array( $format, $supported_formats );
}

function _thrive_get_post_format_fields( $format, $post_id ) {
	$options = array();
	switch ( $format ) {
		case "audio":
			$options['audio_type']                  = get_post_meta( $post_id, '_thrive_meta_postformat_audio_type', true );
			$options['audio_file']                  = get_post_meta( $post_id, '_thrive_meta_postformat_audio_file', true );
			$options['audio_soundcloud_embed_code'] = get_post_meta( $post_id, '_thrive_meta_postformat_audio_soundcloud_embed_code', true );
			break;
		case "gallery":
			$options['gallery_images'] = get_post_meta( $post_id, '_thrive_meta_postformat_gallery_images', true );
			$options['gallery_ids']    = explode( ",", $options['gallery_images'] );
			break;
		case "quote":
			$options['quote_text']   = get_post_meta( $post_id, '_thrive_meta_postformat_quote_text', true );
			$options['quote_author'] = get_post_meta( $post_id, '_thrive_meta_postformat_quote_author', true );
			break;
		case "video":
			$thrive_meta_postformat_video_type        = get_post_meta( $post_id, '_thrive_meta_postformat_video_type', true );
			$thrive_meta_postformat_video_youtube_url = get_post_meta( $post_id, '_thrive_meta_postformat_video_youtube_url', true );
			$thrive_meta_postformat_video_vimeo_url   = get_post_meta( $post_id, '_thrive_meta_postformat_video_vimeo_url', true );
			$thrive_meta_postformat_video_custom_url  = get_post_meta( $post_id, '_thrive_meta_postformat_video_custom_url', true );

			$youtube_attrs = array(
				'hide_logo'       => get_post_meta( $post_id, '_thrive_meta_postformat_video_youtube_hide_logo', true ),
				'hide_controls'   => get_post_meta( $post_id, '_thrive_meta_postformat_video_youtube_hide_controls', true ),
				'hide_related'    => get_post_meta( $post_id, '_thrive_meta_postformat_video_youtube_hide_related', true ),
				'hide_title'      => get_post_meta( $post_id, '_thrive_meta_postformat_video_youtube_hide_title', true ),
				'autoplay'        => get_post_meta( $post_id, '_thrive_meta_postformat_video_youtube_autoplay', true ),
				'hide_fullscreen' => get_post_meta( $post_id, '_thrive_meta_postformat_video_youtube_hide_fullscreen', true ),
				'video_width'     => 1080
			);

			if ( $thrive_meta_postformat_video_type == "youtube" ) {
				$video_code = _thrive_get_youtube_embed_code( $thrive_meta_postformat_video_youtube_url, $youtube_attrs );
			} elseif ( $thrive_meta_postformat_video_type == "vimeo" ) {
				$video_code = _thrive_get_vimeo_embed_code( $thrive_meta_postformat_video_vimeo_url );
			} else {
				if ( strpos( $thrive_meta_postformat_video_custom_url, "<" ) !== false || strpos( $thrive_meta_postformat_video_custom_url, "[" ) !== false ) { //if embeded code or shortcode
					$video_code = do_shortcode( $thrive_meta_postformat_video_custom_url );
				} else {
					$video_code = do_shortcode( "[video src='" . $thrive_meta_postformat_video_custom_url . "']" );
				}
			}
			$options['video_type'] = $thrive_meta_postformat_video_type;
			$options['video_code'] = $video_code;
			break;
	}

	return $options;
}

function _thrive_get_featured_image_style( $post_id = 0 ) {
	if ( $post_id == 0 ) {
		return "thumbnail";
	}
	$feature_img_style = get_post_meta( $post_id, "_thrive_meta_post_featured_image", true );
	if ( empty( $feature_img_style ) || $feature_img_style == "default" ) {
		$feature_img_style = thrive_get_theme_options( "featured_image_style" );
	}

	return $feature_img_style;
}

function _thrive_get_featured_image_size( $post_id = 0 ) {
	if ( $post_id == 0 ) {
		return "thumbnail";
	}
	$feature_img_style = get_post_meta( $post_id, "_thrive_meta_post_featured_image", true );
	if ( empty( $feature_img_style ) || $feature_img_style == "default" ) {
		$feature_img_style = thrive_get_theme_options( "featured_image_style" );
	}
	if ( $feature_img_style == "wide" ) {
		return "large";
	}

	return "thumbnail";
}

function _thrive_get_comments_txt( $no ) {
	if ( $no == 1 ) {
		return __( "comment", 'thrive' );
	} else {
		return __( "comments", 'thrive' );
	}
}

function _thrive_check_display_top_meta_info( $post_id, $options = null ) {
	if ( ! $options ) {
		$options = thrive_get_options_for_post( $post_id );
	}
	$display_info = false;
	//we display the meta info only when the title is displayed or we're not on a page.
	if ( ( isset( $options['show_post_title'] ) && $options['show_post_title'] == 1 ) && ! is_page() ) {
		if ( $options['meta_post_date'] == 1 || $options['meta_post_category'] == 1 ) {
			$display_info = true;
		}
	}

	return $display_info;
}

function _thrive_get_featured_image_src( $postId = null, $params = array() ) {
	if ( ! $postId ) {
		$postId = get_the_ID();
	}
	if ( ! isset( $params['size'] ) || empty( $params['size'] ) ) {
		$params['size'] = "medium";
	}
	$featuredImage = null;
	if ( has_post_thumbnail( $postId ) ) {
		$featuredImage = wp_get_attachment_image_src( get_post_thumbnail_id( $postId ), $params['size'] );
	}
	if ( $featuredImage && isset( $featuredImage[0] ) ) {
		return $featuredImage[0];
	}
	if ( isset( $params['default'] ) && $params['default'] ) {
		return get_template_directory_uri() . "/images/default_featured.jpg";
	}

	return false;
}

function _thrive_render_bottom_related_posts( $postId, $options = null ) {
	if ( ! $postId || ! is_single() ) {
		return false;
	}
	if ( ! $options ) {
		$options = thrive_get_options_for_post( $postId );
	}
	if ( $options['related_posts_box'] != 1 ) {
		return false;
	}
	$postType = get_post_type( $postId );
	if ( $postType != "post" ) {
		return false;
	}

	if ( thrive_get_theme_options( 'related_posts_enabled' ) == 1 ) {
		$relatedPosts = _thrive_get_related_posts( $postId, 'array', $options['related_posts_number'] );
	} else {
		$relatedPosts = get_posts( array(
			'category__in' => wp_get_post_categories( $postId ),
			'numberposts'  => $options['related_posts_number'],
			'post__not_in' => array( $postId )
		) );
	}

	require get_template_directory() . '/partials/bottom-related-posts.php';
}

add_action( 'tha_head_top', 'thrive_include_meta_post_tags' );

function thrive_include_meta_post_tags() {

	if ( _thrive_check_is_woocommerce_page() ) {
		return false;
	}

	$theme_options = thrive_get_options_for_post();

	if ( ! isset( $theme_options['social_site_meta_enable'] ) || $theme_options['social_site_meta_enable'] === null || $theme_options['social_site_meta_enable'] == "" ) {
		$theme_options['social_site_meta_enable'] = _thrive_get_social_site_meta_enable_default_value();
	}

	if ( $theme_options['social_site_meta_enable'] != 1 ) {
		return false;
	}

	if ( is_single() || is_page() ) {
		$plugin_file_path = thrive_get_wp_admin_dir() . "/includes/plugin.php";
		include_once( $plugin_file_path );
		if ( is_plugin_active( 'wordpress-seo/wp-seo.php' ) ) {
			if ( ( ! isset( $theme_options['social_site_title'] ) || $theme_options['social_site_title'] == '' ) &&
			     ( ! isset( $theme_options['social_site_image'] ) || $theme_options['social_site_image'] == '' ) &&
			     ( ! isset( $theme_options['social_site_description'] ) || $theme_options['social_site_description'] == '' ) &&
			     ( ! isset( $theme_options['social_site_twitter_username'] ) || $theme_options['social_site_twitter_username'] == '' )
			) {
				return;
			} else {
				thrive_remove_yoast_meta_description();
			}
		}

		$page_type = 'article';
		if ( ! isset( $theme_options['social_site_title'] ) || $theme_options['social_site_title'] == '' ) {
			$theme_options['social_site_title'] = wp_strip_all_tags( get_the_title() );
		}
		if ( ! isset( $theme_options['social_site_image'] ) || $theme_options['social_site_image'] == '' ) {
			if ( has_post_thumbnail( get_the_ID() ) ) {
				$featured_image = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ) );
				if ( $featured_image && isset( $featured_image[0] ) ) {
					$theme_options['social_site_image'] = $featured_image[0];
				}
			}
		}
		if ( ! isset( $theme_options['social_site_description'] ) || $theme_options['social_site_description'] == '' ) {
			$post    = get_post();
			$content = strip_shortcodes( $post->post_content );
			$content = strip_tags( $content );
			$content = preg_replace( "/\s+/", " ", $content );
			$content = str_replace( '&nbsp;', ' ', $content );

			$first_dot         = strpos( $content, '.' ) !== false ? strpos( $content, '.' ) : strlen( $content );
			$first_question    = strpos( $content, '.' ) !== false ? strpos( $content, '.' ) : strlen( $content );
			$first_exclamation = strpos( $content, '.' ) !== false ? strpos( $content, '.' ) : strlen( $content );

			$fist_sentence                            = min( $first_dot, $first_exclamation, $first_question );
			$content                                  = substr( $content, 0, intval( $fist_sentence ) + 1 );
			$theme_options['social_site_description'] = addslashes( $content );
		}
	} else {
		$page_type = 'website';
	}
	$current_url = get_permalink();

	$meta = array(
		//uniqueID => meta
		'og:type'      => array(
			//attribute -> value
			'property' => 'og:type',
			'content'  => $page_type,
		),
		'og:url'       => array(
			'property' => 'og:url',
			'content'  => $current_url,
		),
		'twitter:card' => array(
			'name'    => 'twitter:card',
			'content' => 'summary_large_image'
		),
	);

	if ( isset( $theme_options['social_site_name'] ) && $theme_options['social_site_name'] != '' ) {
		$meta['og:site_name'] = array(
			'property' => 'og:site_name',
			'content'  => str_replace( '"', "'", $theme_options['social_site_name'] )
		);
	}
	if ( isset( $theme_options['social_site_title'] ) && $theme_options['social_site_title'] != '' ) {
		$meta['og:title']      = array(
			'property' => 'og:title',
			'content'  => str_replace( '"', "'", $theme_options['social_site_title'] ),
		);
		$meta['twitter:title'] = array(
			'name'    => 'twitter:title',
			'content' => str_replace( '"', "'", $theme_options['social_site_title'] )
		);
	}
	if ( isset( $theme_options['social_site_image'] ) && $theme_options['social_site_image'] != '' ) {
		$meta['og:image']          = array(
			'property' => 'og:image',
			'content'  => str_replace( '"', "'", $theme_options['social_site_image'] ),
		);
		$meta['twitter:image:src'] = array(
			'name'    => 'twitter:image:src',
			'content' => str_replace( '"', "'", $theme_options['social_site_image'] )
		);

	}
	if ( isset( $theme_options['social_site_description'] ) && $theme_options['social_site_description'] != '' ) {
		$meta['og:description']      = array(
			'property' => 'og:description',
			'content'  => str_replace( '"', "'", $theme_options['social_site_description'] )
		);
		$meta['twitter:description'] = array(
			'name'    => 'twitter:description',
			'content' => str_replace( '"', "'", $theme_options['social_site_description'] )
		);
	}
	if ( isset( $theme_options['social_site_twitter_username'] ) && $theme_options['social_site_twitter_username'] != '' ) {
		$meta['twitter:creator'] = array(
			'name'    => 'twitter:creator',
			'content' => '@' . str_replace( '"', "'", $theme_options['social_site_twitter_username'] )
		);
		$meta['twitter:site']    = array(
			'name'    => 'twitter:site',
			'content' => '@' . str_replace( '"', "'", $theme_options['social_site_twitter_username'] )
		);
	}

	$meta = apply_filters( 'tha_social_meta', $meta );

	if ( empty( $meta ) ) {
		return;
	}
	echo "\n";
	//display all the meta
	foreach ( $meta as $uniquekey => $attributes ) {
		if ( empty( $attributes ) || ! is_array( $attributes ) ) {
			continue;
		}
		echo "<meta ";
		foreach ( $attributes as $attr_name => $attr_value ) {
			echo $attr_name . '="' . $attr_value . '" ';
		}
		echo "/>\n";
	}
	echo "\n";
}

function thrive_remove_yoast_meta_description() {
	if ( has_action( 'wpseo_head' ) ) {
		if ( isset( $GLOBALS['wpseo_og'] ) ) {
			remove_action( 'wpseo_head', array( $GLOBALS['wpseo_og'], 'opengraph' ), 30 );
		}
		remove_action( 'wpseo_head', array( 'WPSEO_Twitter', 'get_instance' ), 40 );
		remove_action( 'wpseo_head', array( 'WPSEO_GooglePlus', 'get_instance' ), 35 );
	}
}

function thrive_get_wp_admin_dir() {
	$wp_include_dir = preg_replace( '/wp-content$/', 'wp-admin', WP_CONTENT_DIR );

	return $wp_include_dir;
}

function _thrive_check_focus_area_for_pages( $page, $position = "top" ) {
	if ( ! $page ) {
		return false;
	}
	if ( $page == "blog" && ! is_home() ) {
		return false;
	}

	if ( $page == "blog" ) {
		$query = new WP_Query( "post_type=focus_area&meta_key=_thrive_meta_focus_page_blog&meta_value=blog&order=ASC" );
	} elseif ( $page == "archive" ) {
		$query = new WP_Query( "post_type=focus_area&meta_key=_thrive_meta_focus_page_archive&meta_value=archive&order=ASC" );
	}

	$focus_areas = $query->get_posts();

	foreach ( $focus_areas as $focus_area ) {
		$post_custom_atr = get_post_custom( $focus_area->ID );
		if ( isset( $post_custom_atr['_thrive_meta_focus_display_location'] )
		     && isset( $post_custom_atr['_thrive_meta_focus_display_location'][0] )
		     && $post_custom_atr['_thrive_meta_focus_display_location'][0] == $position
		) {
			return true;
		}
	}

	return false;
}

function _thrive_is_active_sidebar( $options = null ) {
	if ( _thrive_check_is_woocommerce_page() ) {
		return is_active_sidebar( 'sidebar-woo' );
	}
	if ( ! $options ) {
		$options = thrive_get_theme_options();
	}
	if ( is_singular() ) {
		$post_template = _thrive_get_item_template( get_the_ID() );
		if ( $post_template == "Narrow" || $post_template == "Full Width" || $post_template == "Landing Page" ) {
			return false;
		}
	}
	if ( is_page() ) {
		$sidebar_is_active = is_active_sidebar( 'sidebar-2' );
	} else {
		$sidebar_is_active = is_active_sidebar( 'sidebar-1' );
	}
	if ( is_singular() ) {
		return $sidebar_is_active;
	}
	if ( $options['blog_layout'] == "full_width" || $options['blog_layout'] == "grid_full_width" || $options['blog_layout'] == "masonry_full_width" || ! $sidebar_is_active ) {
		return false;
	}

	return true;
}