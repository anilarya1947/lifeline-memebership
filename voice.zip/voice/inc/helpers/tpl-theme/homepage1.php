[page_section image="<?php echo $images_dir; ?>/urban_bridge2.jpg" textstyle="light" position="top" padding_bottom="on" fullheight="on"]
<h1>Lorem Ipsum Dolor Sit Amet</h1>
[one_half_first]Nunc tincidunt diam in massa rhoncus condimentum. Etiam suscipit enim vitae purus fringilla venenatis. Phasellus rhoncus, turpis eget tempus tincidunt, erat mi porta purus.

&nbsp;

[thrive_link color="orange" link="#" target="_self" size="big" align="aligncenter"]Sign Up Today![/thrive_link][/one_half_first][one_half_last][/one_half_last] [/page_section]
<h2 style="text-align: center;">Our Services</h2>
[divider style="dark"]

[one_third_first][thrive_text_block color="blue" headline=""]<img class="aligncenter size-full wp-image-418" alt="icon1"
                                                                  src="<?php echo $images_dir; ?>/icon1.png" width="78"
                                                                  height="68"/>
<p style="text-align: center;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pharetra facilisis
	sem sed rhoncus. Nullam varius arcu non ante mattis, et ultricies nulla
	volutpat.[/thrive_text_block][/one_third_first][one_third][thrive_text_block color="green" headline=""]<img
		class="aligncenter size-full wp-image-419" alt="icon2" src="<?php echo $images_dir; ?>/icon2.png" width="78"
		height="68"/></p>
<p style="text-align: center;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pharetra facilisis
	sem sed rhoncus. Nullam varius arcu non ante mattis, et ultricies nulla volutpat.
	[/thrive_text_block][/one_third][one_third_last][thrive_text_block color="orange" headline=""]<img
		class="aligncenter size-full wp-image-420" alt="icon3" src="<?php echo $images_dir; ?>/icon3.png" width="78"
		height="68"/></p>
<p style="text-align: center;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque pharetra facilisis
	sem sed rhoncus. Nullam varius arcu non ante mattis, et ultricies nulla
	volutpat.[/thrive_text_block][/one_third_last]</p>

<h2 style="text-align: center;">Another Sub-Heading</h2>
[divider style="dark"]
<p style="text-align: center;">Proin pulvinar, justo eget tristique dictum, sapien tellus pharetra quam, et rutrum odio
	diam non odio. Duis eu dui id enim sagittis tempus in id dolor. Sed gravida metus nec dignissim egestas. Phasellus
	congue purus eget eros volutpat sagittis. Sed eu augue consequat, pharetra nunc non, bibendum lectus.</p>

<h2 style="text-align: center;">The Latest From Our Blog</h2>
[divider style="dark"]

[thrive_posts_gallery title="" no_posts="4" filter="recent"]

[thrive_text_block color="light" headline=""]
<h2 style="text-align: center;">Never Miss a New Post! Join Our Newsletter:</h2>
[thrive_optin color="green" text="Subscribe Now" optin="<?php echo $optin_id; ?>" size="medium" layout="horizontal"][/thrive_text_block]