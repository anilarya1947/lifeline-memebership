[page_section image="<?php echo $images_dir; ?>/blurred-bg-1.jpg" textstyle="light" position="top" padding_bottom="on"]
<h1 style="text-align: center;"><strong>Attention-Grabbing Headline Goes Here!</strong></h1>
[two_third_first]<img class="aligncenter size-full wp-image-463" alt="video-placeholder-800"
                      src="<?php echo $images_dir; ?>/video-placeholder-800.png" width="800"
                      height="450"/>[/two_third_first][one_third_last]
<h3>Sub-Heading Goes Here!</h3>
Sign up below to receive instant access to {Title of Your Free Product Here}.

Enter your name and email address below to get started right away!

[thrive_optin color="orange" text="Get Instant Access!" optin="<?php echo $optin_id; ?>" size="medium" layout="vertical"][/one_third_last][/page_section]

[thrive_testimonial name="Example Guy" company="" image="<?php echo $images_dir; ?>/testimonial-pic.jpg" style="dark"]A positive testimonial from one or several of your users can boost conversions. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce consectetur sem quis metus tempus rhoncus.[/thrive_testimonial]

[thrive_testimonial name="Other Guy" company="" image="" style="dark"]Sed scelerisque enim ut justo tempus, id luctus odio aliquet. Vestibulum nec dapibus neque. Ut ultrices, nisl vel fermentum tristique, dui enim tempor lacus, id condimentum metus ante vel augue. Aliquam pulvinar quam vel augue vestibulum euismod. Nunc blandit mollis orci, vitae pellentesque nulla eleifend a.[/thrive_testimonial]