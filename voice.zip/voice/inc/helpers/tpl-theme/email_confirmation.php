<h1 style="text-align: center;"><strong>Congratulations for Signing Up!</strong></h1>
<h3 style="text-align: center;">Here are your IMPORTANT next steps:</h3>
<p style="text-align: center;">To make sure we got the right email address, we need you to click on a confirmation link
	in an email we just sent to you.</p>
[one_third_first][thrive_text_block color="blue" headline="Step 1:"]Go to your <strong>email
	inbox</strong> (of the email address you signed up with).[/thrive_text_block][/one_third_first]
[one_third][thrive_text_block color="blue" headline="Step 2:"]Find the email sent by
<strong>YourFromNameHere</strong>, with the subject line: <strong>Your Subject Line
	Here</strong>.[/thrive_text_block][/one_third]
[one_third_last][thrive_text_block color="blue" headline="Step 3:"]Open this email and <strong>click on the link
	inside</strong>. That's it! The process will then complete automatically.[/thrive_text_block][/one_third_last]

Once you've completed the confirmation steps, you will get immediate access to the free report/the bonuses/the exclusive content/whatever you signed up for!
