<h1 style="text-align: center; font-size: 2.7em;">Sign Up to Get Your Free Report/Product/Download!</h1>
<h3 style="text-align: center;">Subheading emphasizes how cool your free thing is.</h3>
[one_half_first]The time to make a change is now!

Download our free report/product/whatever, to get the following benefits:
<ul>
	<li><strong>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </strong></li>
	<li>Donec mollis, dolor et consectetur hendrerit.</li>
	<li><strong>Metus nisl interdum felis, nec venenatis eros ligula convallis ligula.</strong></li>
	<li>Cras dapibus orci urna, in sagittis justo rutrum non.</li>
	<li><strong>Ut consequat lectus a elementum convallis. </strong></li>
	<li>Fusce sodales metus ut massa vehicula.</li>
</ul>
All this and more is yours for FREE!

[/one_half_first][one_half_last]
<img class="aligncenter size-full wp-image-226" alt="cover-image-1b" src="<?php echo $images_dir; ?>/cover-image-1b.png"
     width="386" height="450"/>[/one_half_last]

[page_section template="1" position="bottom" padding_top="on"]
<h2 style="text-align: center;">Just Enter Your Name and Email Address Below
	to Instantly Receive Your Report:</h2>
[thrive_optin color="orange" text="Get Instant Access!" optin="<?php echo $optin_id; ?>" size="big" layout="horizontal"]

[/page_section]