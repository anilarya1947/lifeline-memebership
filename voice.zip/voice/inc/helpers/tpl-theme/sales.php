[page_section color="#2d4e92" textstyle="light" position="top" shadow="#2b3972" padding_bottom="on"]
<h1 style="text-align: center;">This is Where You Put a <strong>Big Headline</strong>. Make Your Visitors
	<strong>Want</strong> to Know More...</h1>
<h3 style="text-align: center;">And don't forget how useful a well-written sub-heading can be.</h3>
<img class="aligncenter size-full wp-image-463" alt="video-placeholder-800"
     src="<?php echo $images_dir; ?>/video-placeholder-800.png" width="800" height="450"/>

[thrive_link color="green" link="#" target="_self" size="big" align="aligncenter"]Click Here to Start Your Free Trial[/thrive_link]

[/page_section]

A simple paragraph, leading with the main benefit of your product and the main reason your visitors should consider buying it. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque dapibus diam non mollis vestibulum. Cras rhoncus urna metus, in hendrerit neque vestibulum quis.

[divider"]
<h2 style="text-align: center;">How You'll Benefit From This Product:</h2>
[one_fourth_first]<img class="aligncenter size-full wp-image-479" alt="icon4" src="<?php echo $images_dir; ?>/icon4.png"
                       width="55" height="48"/>
<p style="text-align: center;"><strong>Lorem Ipsum Dolor</strong></p>
<p style="text-align: center;">Sit amet, consectetur adipiscing elit. Pellentesque dapibus diam non mollis vestibulum.
	Cras rhoncus urna metus, in hendrerit neque vestibulum quis.[/one_fourth_first][one_fourth]<img
		class="aligncenter size-full wp-image-480" alt="icon5" src="<?php echo $images_dir; ?>/icon5.png" width="64"
		height="48"/></p>
<p style="text-align: center;"><strong>Ut Tellus Odio Ultricies</strong></p>
<p style="text-align: center;">A vehicula ut, fermentum in neque. Nullam pharetra pretium vestibulum. Pellentesque porta
	venenatis velit, vel dapibus neque dapibus quis.[/one_fourth][one_fourth]<img
		class="aligncenter size-full wp-image-482" alt="icon6" src="<?php echo $images_dir; ?>/icon6.png" width="42"
		height="48"/></p>
<p style="text-align: center;"><strong>Nunc Lobortis Sed</strong></p>
<p style="text-align: center;">Sapien ut tristique. Fusce luctus imperdiet tempus. Phasellus a tortor aliquet leo at,
	tristique tellus. Quisque at condimentum elit.[/one_fourth][one_fourth_last]<img
		class="aligncenter size-full wp-image-483" alt="icon7" src="<?php echo $images_dir; ?>/icon7.png" width="55"
		height="48"/></p>
<p style="text-align: center;"><strong>Nam Malesuada Lectus</strong></p>
<p style="text-align: center;">Id feugiat facilisis, est leo congue dolor, quis auctor enim arcu non sem. Vivamus
	gravida lacinia interdum. Curabitur malesuada lacus.[/one_fourth_last]</p>
[one_fourth_first]<img class="aligncenter size-full wp-image-485" alt="icon8" src="<?php echo $images_dir; ?>/icon8.png"
                       width="50" height="48"/>
<p style="text-align: center;"><strong>Nunc Lobortis Sed</strong></p>
<p style="text-align: center;">Sapien ut tristique. Fusce luctus imperdiet tempus. Phasellus a tortor aliquet leo at,
	tristique tellus. Quisque at condimentum elit.[/one_fourth_first][one_fourth]<img
		class="aligncenter size-full wp-image-486" alt="icon9" src="<?php echo $images_dir; ?>/icon9.png" width="48"
		height="48"/></p>
<p style="text-align: center;"><strong>Lorem Ipsum Dolor</strong></p>
<p style="text-align: center;">Sit amet, consectetur adipiscing elit. Pellentesque dapibus diam non mollis vestibulum.
	Cras rhoncus urna metus, in hendrerit neque vestibulum quis.[/one_fourth][one_fourth]<img
		class="aligncenter size-full wp-image-487" alt="icon10" src="<?php echo $images_dir; ?>/icon10.png" width="48"
		height="48"/></p>
<p style="text-align: center;"><strong>Ut Tellus Odio Ultricies</strong></p>
<p style="text-align: center;">A vehicula ut, fermentum in neque. Nullam pharetra pretium vestibulum. Pellentesque porta
	venenatis velit, vel dapibus neque dapibus quis.[/one_fourth][one_fourth_last]<img
		class="aligncenter size-full wp-image-488" alt="icon11" src="<?php echo $images_dir; ?>/icon11.png" width="48"
		height="48"/></p>
<p style="text-align: center;"><strong>Nunc Lobortis Sed</strong></p>
<p style="text-align: center;">Sapien ut tristique. Fusce luctus imperdiet tempus. Phasellus a tortor aliquet leo at,
	tristique tellus. Quisque at condimentum elit.[/one_fourth_last]</p>
[divider]
<h2 style="text-align: center;">A New Sub-Heading, to Lead Into the Next Part:</h2>
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam tincidunt lacinia vehicula. Aenean pretium dui ac sem ultricies, ut rutrum purus dapibus. Vivamus blandit ornare elit sodales eleifend.

<img class="aligncenter size-full wp-image-491" alt="icon-set" src="<?php echo $images_dir; ?>/icon-set.png" width="785"
     height="207"/>

Use images and illustrations frequently, to avoid a wall-of-text impression on your page. <strong>Whenever possible,
	illustrate the benefits of your product. in other words: show, don't just tell.</strong>

Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor felis ut urna adipiscing, id condimentum quam auctor. Donec eleifend sit amet ligula sed blandit. Fusce lacinia, dui nec pharetra scelerisque, massa dui aliquam leo, venenatis ultrices sem velit non augue. Integer non volutpat mi, quis molestie diam. Quisque sit amet commodo nibh, id iaculis arcu. Mauris quis quam imperdiet, laoreet nisi non, posuere urna. Donec ut metus risus.

[page_section color="#2d4e92" textstyle="light" position="default" shadow="#2b3972" padding_bottom="on" padding_top="on"]
<h2 style="text-align: center;">What Our Customers Are Saying:</h2>
[one_half_first][thrive_testimonial name="ExampleGuy" company="Editor at ExampleSite" image="<?php echo $images_dir; ?>/testimonial-pic.jpg"]"Pellentesque ut nunc sit amet mi vestibulum tincidunt sit amet vel leo. Phasellus et dolor at velit molestie blandit. In a justo sit amet erat pretium rutrum sed at metus. In vitae arcu magna. Morbi vel fermentum ligula."[/thrive_testimonial][/one_half_first][one_half_last][thrive_testimonial name="Happy Customer" company="" image=""]"Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor felis ut urna adipiscing, id condimentum quam auctor. Donec eleifend sit amet ligula sed blandit. Fusce lacinia, dui nec pharetra scelerisque."[/thrive_testimonial][/one_half_last]

[one_half_first][thrive_testimonial name="Another Customer" company="" image=""]"Vestibulum eget sollicitudin arcu, non fringilla neque. Phasellus sodales augue id massa tempus, ut ultricies justo lacinia. Nunc a neque vestibulum, aliquet justo eget, lacinia augue. Donec lacinia, est vitae fringilla luctus, augue est sollicitudin nulla, id laoreet arcu sapien quis diam."[/thrive_testimonial][/one_half_first][one_half_last][thrive_testimonial name="Testimonial Gal" company="" image=""]"Cras vel nulla non felis eleifend volutpat. Donec sodales convallis turpis, vel pharetra justo. Curabitur porta justo ac odio sagittis, in pharetra sapien vehicula. Donec sed ipsum magna. Nam vel aliquam odio, lacinia lacinia turpis."[/thrive_testimonial][/one_half_last]

[/page_section]
<h2 style="text-align: center;">Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing</h2>
Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor felis ut urna adipiscing, id condimentum quam auctor. Donec eleifend sit amet ligula sed blandit. Fusce lacinia, dui nec pharetra scelerisque, massa dui aliquam leo, venenatis ultrices sem velit non augue.

[thrive_text_block color="note" headline=""]
<h3>What You'll Get When You Sign Up Today:<img class="alignright  wp-image-226" alt="cover-image-1b"
                                                src="<?php echo $images_dir; ?>/cover-image-1b.png" width="232"
                                                height="270"/></h3>
<ul>
	<li>Donec lacinia, est vitae fringilla luctus.</li>
	<li><strong>Augue est sollicitudin nulla, id laoreet arcu sapien quis diam.</strong></li>
	<li>Morbi sed nunc magna.</li>
	<li><strong>Vestibulum ante ipsum primis in faucibus.</strong></li>
	<li>Orci luctus et ultrices posuere cubilia.</li>
	<li><strong>Curae; Vivamus orci dui, laoreet et.</strong></li>
	<li>Dui ut, dapibus venenatis ipsum.</li>
</ul>
[/thrive_text_block]

[divider]
<h2 style="text-align: center;">Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing</h2>
Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor felis ut urna adipiscing, id condimentum quam auctor. Donec eleifend sit amet ligula sed blandit. Fusce lacinia, dui nec pharetra scelerisque, massa dui aliquam leo, venenatis ultrices sem velit non augue.

Vestibulum eget sollicitudin arcu, non fringilla neque. Phasellus sodales augue id massa tempus, ut ultricies justo lacinia. Nunc a neque vestibulum, aliquet justo eget, lacinia augue. Donec lacinia, est vitae fringilla luctus, augue est sollicitudin nulla, id laoreet arcu sapien quis diam.

[divider]

[one_third_first][thrive_text_block color="light" headline=""]
<h3 style="text-align: center;">Silver</h3>
<p style="text-align: center;">Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor
	felis ut urna adipiscing.</p>
<p style="text-align: center;"><strong>$12/month</strong></p>
[thrive_link color="orange" link="#" target="_self" size="medium" align="aligncenter"]Add to Cart[/thrive_link]

[/thrive_text_block][/one_third_first][one_third][thrive_text_block color="light" headline=""]
<h3 style="text-align: center;">Gold</h3>
<p style="text-align: center;">Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor
	felis ut urna adipiscing.</p>
<p style="text-align: center;"><strong>$30/month</strong></p>
[thrive_link color="orange" link="#" target="_self" size="medium" align="aligncenter"]Add to Cart[/thrive_link]

[/thrive_text_block][/one_third][one_third_last][thrive_text_block color="light" headline=""]
<h3 style="text-align: center;">Platinum</h3>
<p style="text-align: center;">Mauris cursus erat eget elit hendrerit, sed posuere elit vestibulum. Curabitur porttitor
	felis ut urna adipiscing.</p>
<p style="text-align: center;"><strong>$90/month</strong></p>
[thrive_link color="orange" link="#" target="_self" size="medium" align="aligncenter"]Add to Cart[/thrive_link]

[/thrive_text_block][/one_third_last]
<p style="text-align: center;"><em>All plans include our free installation service.</em></p>
[page_section color="#2d4e92" textstyle="light" shadow="#2b3972" position="bottom" padding_top="on"]
<h2 style="text-align: center;">100% Satisfaction Guarantee</h2>
<p style="text-align: center;">You have a full 30 days to test our product. If you aren"t completely satisfied with the
	service you receive, just ask and we will gladly give you a full refund on your purchase price. Give it a try, the
	risk is on us!</p>
[/page_section]