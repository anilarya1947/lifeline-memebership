<h1 style="text-align: center;">Thank You for Signing Up!</h1>
<p style="text-align: center;">Here's your free report/e-book/software/download:</p>
<img class="aligncenter size-full wp-image-226" alt="cover-image-1b" src="<?php echo $images_dir; ?>/cover-image-1b.png"
     width="386" height="450"/>
<p style="text-align: center;"><a href="#">Right click and select "Save link as..."</a>
	<a href="#">or "Save target as..." to download this file.</a></p>
&nbsp;

If you have any questions about the report or would like to share your thoughts about it, you can always get in touch with us here:
<a href="#">link to contact page.</a>

[thrive_text_block color="note" headline=""]
<h3>Did You Know...</h3>
We also have a premium product/premium membership/offer coaching or consulting? (Use this space to advertise a premium service or product. Don"t push hard, at this point, but use the opportunity to make sure your new subscribers are aware of your products or services.)[/thrive_text_block]