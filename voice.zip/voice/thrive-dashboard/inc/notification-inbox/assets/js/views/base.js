/**
 * Created by Dan Brinzaru on 4/25/2019.
 */

( function ( $ ) {
	module.exports = Backbone.View.extend( {
		render: function () {
			return this;
		}
	} )

} )( jQuery );
