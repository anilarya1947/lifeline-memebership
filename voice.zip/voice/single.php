<?php
$options = thrive_get_options_for_post( get_the_ID() );
?>

<?php get_header(); ?>

<?php get_sidebar(); ?>

<section class="bSe fullWidth "><!--Start the section wrapper-->
	<div class="flex-cnt">
		<?php
		if ( thrive_check_top_focus_area() ):
			thrive_render_top_focus_area();
		endif;
		?>
		<div class="wrp">
			<?php get_template_part( 'breadcrumbs' ); ?>
			<?php if ( have_posts() ): ?>
				<?php while ( have_posts() ): ?>
					<?php the_post(); ?>
					<?php get_template_part( 'content', 'single' ); ?>

					<?php
					if ( thrive_check_bottom_focus_area() ):
						thrive_render_top_focus_area( "bottom" );
						?>
					<?php endif; ?>

					<?php if ( ! post_password_required() ) : ?>
						<?php comments_template( '', true ); ?>
					<?php elseif ( ( ! comments_open() ) && get_comments_number() > 0 ): ?>
						<?php comments_template( '/comments-disabled.php' ); ?>
					<?php endif; ?>
				<?php endwhile; ?>

				<div class="clear"></div>

				<?php
				if ( isset( $options['bottom_previous_next'] ) && $options['bottom_previous_next'] == 1 && get_permalink( get_adjacent_post( false, '', false ) ) != "" && get_permalink( get_adjacent_post( false, '', true ) ) != "" ):
					$previous_post_link = get_permalink( get_adjacent_post( false, '', true ) );
					$next_post_link = get_permalink( get_adjacent_post( false, '', false ) );
					?>
					<div class="pnav">
						<?php if ( $previous_post_link != get_permalink() ): ?>
							<a class="pav left" href="<?php echo $previous_post_link; ?>">
								<span><?php _e( "Previous post", 'thrive' ); ?>:</span>
								<span><?php echo get_the_title( get_adjacent_post( false, '', true ) ); ?></span>
							</a>
						<?php endif; ?>
						<?php if ( $next_post_link != get_permalink() ): ?>
							<a class="pav right" href="<?php echo $next_post_link; ?>">
								<span><?php _e( "Next post", 'thrive' ) ?>:</span>
								<span><?php echo get_the_title( get_adjacent_post( false, '', false ) ); ?></span>
							</a>
						<?php endif; ?>
						<div class="clear"></div>
					</div>
				<?php endif; ?>
			<?php else: ?>
				<!--No contents-->
			<?php endif ?>
		</div>
	</div>
	<?php get_footer(); ?>