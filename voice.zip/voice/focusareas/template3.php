<?php
$focus_area_class   = $current_attrs['_thrive_meta_focus_color'][0];
$wrapper_class      = ( $position == "top" ) ? "wrp" : "wrp lfa";
$section_position   = ( $position == "bottom" ) ? "farb" : "";
$btn_class          = ( empty( $current_attrs['_thrive_meta_focus_button_color'][0] ) ) ? "blue" : strtolower( $current_attrs['_thrive_meta_focus_button_color'][0] );
$action_link_target = ( $current_attrs['_thrive_meta_focus_new_tab'][0] == 1 ) ? "_blank" : "_self";
?>

<div class="far fab f3 <?php echo $focus_area_class; ?>">
	<div class="csc">
		<div class="colm tth">
			<?php if ( ! empty( $current_attrs['_thrive_meta_focus_image'][0] ) ): ?>
				<div class="csc">
					<div class="colm foai">
						<img src="<?php echo $current_attrs['_thrive_meta_focus_image'][0]; ?>" alt="">
					</div>
					<div class="colm foat lst">
						<h4><?php echo $current_attrs['_thrive_meta_focus_heading_text'][0]; ?></h4>

						<p><?php echo nl2br( do_shortcode( $current_attrs['_thrive_meta_focus_subheading_text'][0] ) ); ?></p>
					</div>
					<div class="clear"></div>
				</div>
			<?php else: ?>
				<h4><?php echo $current_attrs['_thrive_meta_focus_heading_text'][0]; ?></h4>
				<p><?php echo nl2br( do_shortcode( $current_attrs['_thrive_meta_focus_subheading_text'][0] ) ); ?></p>
			<?php endif; ?>
		</div>
		<div class="colm thc lst">
			<a href="<?php echo $current_attrs['_thrive_meta_focus_button_link'][0]; ?>"
			   class="big btn <?php echo $btn_class; ?> big" target="<?php echo $action_link_target; ?>">
				<span><?php echo $current_attrs['_thrive_meta_focus_button_text'][0]; ?></span>
			</a>
		</div>
		<div class="clear"></div>
	</div>
</div>