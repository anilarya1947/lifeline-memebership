<section>
	<div class="scn">
		<p class="ttl">Search</p>

		<form class="srh" action="<?php echo home_url( '/' ); ?>" method="get">
			<div>
				<input type="text" class="search-field" placeholder="Search" name="s">
				<button class="search-button" type="submit"></button>
				<div class="clear"></div>
			</div>
		</form>
	</div>
</section>