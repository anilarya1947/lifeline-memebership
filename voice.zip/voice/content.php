<?php
$options                               = thrive_get_theme_options();
$options['featured_image_style']       = _thrive_get_featured_image_style( get_the_ID() );
$featured_image_data                   = thrive_get_post_featured_image( get_the_ID(), $options['featured_image_style'] );
$featured_image                        = $featured_image_data['image_src'];
$featured_image_alt                    = $featured_image_data['image_alt'];
$featured_image_title                  = $featured_image_data['image_title'];
$post_format                           = get_post_format();
$post_format_options                   = _thrive_get_post_format_fields( $post_format, get_the_ID() );
$thrive_meta_postformat_gallery_images = trim( get_post_meta( get_the_ID(), '_thrive_meta_postformat_gallery_images', true ), "," );
$thrive_gallery_ids                    = explode( ",", $thrive_meta_postformat_gallery_images );
?>
<?php tha_entry_before(); ?>

	<article class="<?php
	if ( is_sticky() ): echo 'sty';
	endif;
	?> <?php
	if ( $post_format == "image" || $post_format == "gallery" ):echo 'ip';
	endif;
	?>">
		<div class="cnt">

			<?php if ( $post_format == "image" && $featured_image ): ?>
				<a class="fwI" href="<?php the_permalink(); ?>">
					<img class="" src="<?php echo $featured_image; ?>" alt="<?php echo $featured_image_alt; ?>"
					     title="<?php echo $featured_image_title; ?>"/>
				</a>
			<?php endif; ?>

			<?php if ( $post_format == "gallery" ): ?>
				<div class="" id="thrive-gallery-header-<?php echo get_the_ID(); ?>"
				     data-count="<?php echo count( $thrive_gallery_ids ); ?>" data-index="0">
					<?php if ( $post_format_options['gallery_ids'] && isset( $post_format_options['gallery_ids'][0] ) ): ?>
						<?php if ( $img_url = wp_get_attachment_url( $post_format_options['gallery_ids'][0] ) ): ?>
							<a href="<?php the_permalink(); ?>">
								<div class="hru hui" style="background-image: url('<?php echo trim( $img_url ); ?>')">
									<img id="thive-gallery-dummy" class=" gallery-dmy"
									     src="<?php echo trim( $img_url ); ?>" alt="">
								</div>
							</a>
						<?php endif; ?>
					<?php endif; ?>

					<div class="gnav clearfix">
						<a class="gprev" href=""><?php _e( "Previous Image", 'thrive' ); ?></a>

						<div class="gwrp">
							<ul class="clearfix">
								<?php
								foreach ( $post_format_options['gallery_ids'] as $key => $id ):
									if ( $img_url = wp_get_attachment_url( $id ) ):
										?>
										<li id="li-thrive-gallery-item-<?php echo $key; ?>">
											<a class="thrive-gallery-item" href=""
											   style="background-image: url('<?php echo trim( $img_url ); ?>');"
											   data-image="<?php echo trim( $img_url ); ?>"
											   data-index="<?php echo $key; ?>"></a>
										</li>
										<?php
									endif;
								endforeach;
								?>
							</ul>
						</div>
						<a class="gnext" href=""><?php _e( "Next Image", 'thrive' ); ?></a>
					</div>
				</div>
			<?php endif; ?>

			<?php if ( $post_format == "quote" ): ?>
				<div class="hru">
					<div class="quo">
						<h2 class="entry-title"><a
								href="<?php the_permalink(); ?>"><?php echo $post_format_options['quote_text']; ?></a>
						</h2>
						<?php if ( ! empty( $post_format_options['quote_author'] ) ): ?>
							<p>- <?php echo $post_format_options['quote_author']; ?></p>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<?php if ( $post_format != "quote" ): ?>
				<h2 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
			<?php endif; ?>
			<?php if ( _thrive_check_display_top_meta_info( get_the_ID() ) ): ?>
				<div class="pm">
					<?php $separator_txt = ""; ?>
					<?php _e( "Published", 'thrive' ); ?>
					<?php
					if ( isset( $options['meta_post_date'] ) && $options['meta_post_date'] == 1 ):
						$separator_txt = " - ";
						?>
						<?php if ( $options['relative_time'] == 1 ): ?>
						<?php echo thrive_human_time( get_the_time( 'U' ) ); ?>
					<?php else: ?>
						<?php echo get_the_date(); ?>
					<?php endif; ?>
					<?php endif; ?>

					<?php if ( isset( $options['meta_post_category'] ) && $options['meta_post_category'] == 1 ): ?>
						<?php
						$categories = get_the_category();
						if ( $categories ):
							$separator_txt = " - ";
							?>
							<?php _e( "in", 'thrive' ); ?>
							<?php if ( count( $categories ) > 1 ): ?>
							<?php foreach ( $categories as $key => $category ): ?>
								<a href="<?php echo get_category_link( $category->term_id ); ?>"><?php echo $category->cat_name; ?></a>
								<?php if ( $key != count( $categories ) - 1 && isset( $categories[ $key + 1 ] ) ): ?>,<?php endif; ?>
							<?php endforeach; ?>
						<?php elseif ( isset( $categories[0] ) ): ?>
							<a href="<?php echo get_category_link( $categories[0]->term_id ); ?>"><?php echo $categories[0]->cat_name; ?></a>
						<?php endif; ?>
						<?php endif; ?>
					<?php endif; ?>
					<?php $cn = get_comments_number() ?>
					<a href="<?php the_permalink(); ?>#comments"
					   <?php if ( $options['meta_comment_count'] != 1 || $cn == 0 ): ?>style='display:none;'<?php endif; ?>>
						<?php echo $separator_txt . $cn; ?>
						<?php echo _n( 'Comment', 'Comments', $cn, 'thrive' ); ?>
					</a>
				</div>
			<?php endif; ?>

			<?php if ( ! _thrive_is_supported_format( $post_format ) || $post_format == "audio" ): //standard format         ?>
				<?php if ( $options['featured_image_style'] == "thumbnail" && $featured_image && $post_format != "audio" ): ?>
					<a href="<?php the_permalink(); ?>">
						<img src="<?php echo $featured_image; ?>" alt="<?php echo $featured_image_alt; ?>"
						     title="<?php echo $featured_image_title; ?>" class="afim"/>
					</a>
				<?php endif; ?>
				<?php if ( $options['featured_image_style'] == "wide" && $featured_image ): ?>
					<a class="fwI" href="<?php the_permalink(); ?>">
						<img class="" src="<?php echo $featured_image; ?>" alt="<?php echo $featured_image_alt; ?>"
						     title="<?php echo $featured_image_title; ?>"/>
					</a>
				<?php endif; ?>

				<?php if ( $post_format == "audio" ): ?>
					<?php if ( $post_format_options['audio_type'] != "soundcloud" ): ?>
						<?php echo do_shortcode( "[audio src='" . $post_format_options['audio_file'] . "'][/audio]" ); ?>
					<?php else: ?>
						<?php echo $post_format_options['audio_soundcloud_embed_code']; ?>
					<?php endif; ?>
				<?php endif; ?>

				<?php if ( $options['featured_image_style'] == "thumbnail" && $featured_image && $post_format == "audio" ): ?>
					<a href="<?php the_permalink(); ?>">
						<img src="<?php echo $featured_image; ?>" alt="<?php echo $featured_image_alt; ?>"
						     title="<?php echo $featured_image_title; ?>" class="afim"/>
					</a>
				<?php endif; ?>

				<?php if ( $options['other_show_excerpt'] != 1 ): ?>
					<?php the_content(); ?>
				<?php else: ?>
					<?php the_excerpt(); ?>
					<?php if ( $options['other_show_excerpt'] == 1 ): ?>
						<?php $read_more_text = ( ! empty( $options['other_read_more_text'] ) ) ? $options['other_read_more_text'] : __( "Read more", 'thrive' ); ?>
						<div class="rme left">
							<a href="<?php the_permalink(); ?>"><?php echo $read_more_text; ?></a>
						</div>
					<?php else: ?>
						<a href='<?php the_permalink(); ?>' class=''><?php echo $read_more_text; ?></a>
					<?php endif; ?>
				<?php endif; ?>

				<?php if ( isset( $options['display_meta'] ) && $options['display_meta'] == 1 && isset( $options['meta_post_tags'] ) && $options['meta_post_tags'] == 1 ): ?>
					<?php if ( $posttags = get_the_tags() ): ?>
						<div class="tgs right">
							<?php _e( "Tags", 'thrive' ); ?>:
							<?php
							$index = 0;
							foreach ( $posttags as $key => $tag ):
								?>
								<a href="<?php echo get_tag_link( $tag->term_id ); ?>"><?php echo $tag->name; ?></a>
								<?php if ( $index != count( $posttags ) - 1 ): ?>,<?php endif; ?>
								<?php
								$index ++;
							endforeach;
							?>
						</div>
					<?php endif; ?>
				<?php endif; ?>
			<?php endif; ?>

			<?php if ( $post_format == "video" ): ?>
				<?php $wistiaVideoCode = ( strpos( $post_format_options['video_code'], "wistia" ) !== false ) ? ' wistia-video-container' : ''; ?>
				<?php if ( $featured_image ): ?>
					<div class="scvps bpt<?php echo $wistiaVideoCode; ?>"
					     style="background-image: url('<?php echo $featured_image; ?>')">
						<div class="vdc lv">
							<div class="ltx">
								<div class="pvb">
									<a href=""></a>
								</div>
							</div>
						</div>
						<div class="vdc lv video-container" style="display: none;">
							<div class="vwr">
								<?php echo $post_format_options['video_code']; ?>
							</div>
						</div>
					</div>
				<?php else: ?>
					<?php echo $post_format_options['video_code']; ?>
				<?php endif; ?>
			<?php endif; ?>

			<div class="clear"></div>
		</div>
	</article>
<?php _thrive_render_bottom_related_posts( get_the_ID(), $options ); ?>