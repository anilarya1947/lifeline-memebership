<?php
$options = thrive_get_options_for_post( get_the_ID() );

$section_class = "fullWidth";

?>

<?php get_header(); ?>

<?php get_sidebar(); ?>

<section class="bSe <?php echo $section_class; ?> "><!--Start the section wrapper-->
	<?php
	if ( thrive_check_top_focus_area() ):
		thrive_render_top_focus_area();
	endif;
	?>
	<div class="wrp">
		<?php get_template_part( 'breadcrumbs' ); ?>
		<?php if ( have_posts() ): ?>
			<?php while ( have_posts() ): ?>
				<?php the_post(); ?>
				<?php get_template_part( 'content', 'single' ); ?>

				<?php
				if ( thrive_check_bottom_focus_area() ):
					thrive_render_top_focus_area( "bottom" );
					?>
				<?php endif; ?>

				<?php if ( ! post_password_required() && $options['comments_on_pages'] != 0 ) : ?>
					<?php comments_template( '', true ); ?>
				<?php elseif ( ( ! comments_open() ) && get_comments_number() > 0 ): ?>
					<?php comments_template( '/comments-disabled.php' ); ?>
				<?php endif; ?>
			<?php endwhile; ?>

			<div class="clear"></div>


		<?php else: ?>
			<!--No contents-->
		<?php endif ?>
	</div>
	<?php get_footer(); ?>