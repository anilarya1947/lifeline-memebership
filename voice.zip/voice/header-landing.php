<?php
$options         = thrive_get_options_for_post( get_the_ID() );
$logo_width_txt  = "";
$logo_height_txt = "";
if ( $options['logo_width'] <= 200 && $options['logo_height'] <= 100 && $options['logo_width'] != "" && $options['logo_height'] != "" ) {
	$logo_width_txt  = "width='" . $options['logo_width'] . "'";
	$logo_height_txt = "height='" . $options['logo_height'] . "'";
}
$enable_fb_comments = thrive_get_theme_options( "enable_fb_comments" );
$fb_app_id          = thrive_get_theme_options( "fb_app_id" );
$float_menu_attr    = "";
if ( $options['navigation_type'] == "float" || $options['navigation_type'] == "scroll" ) {
	$float_menu_attr = ( $options['navigation_type'] == "float" ) ? " data-float='float-fixed'" : " data-float='float-scroll'";
}
?>
<!DOCTYPE html>
<? tha_html_before(); ?>
<html <?php language_attributes(); ?>>
<head>
	<?php tha_head_top(); ?>
	<title>
		<?php wp_title( '' ); ?>
	</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<!--[if lt IE 9]>
	<script src="<?php echo get_template_directory_uri() ?>/js/html5/dist/html5shiv.js"></script>
	<![endif]-->
	<!--[if IE]>
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() ?>/css/ie.css"/>
	<![endif]-->
	<!--[if lt IE 9]>
	<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri() ?>/css/ie8.css"/>
	<![endif]-->
	<?php thrive_enqueue_head_fonts(); ?>
	<?php wp_head(); ?>
	<?php if ( $options['favicon'] && $options['favicon'] != "" ): ?>
		<link rel="shortcut icon" href="<?php echo $options['favicon']; ?>"/>
	<?php endif; ?>
	<?php if ( isset( $options['analytics_header_script'] ) && $options['analytics_header_script'] != "" ): ?>
		<?php echo $options['analytics_header_script']; ?>
	<?php endif; ?>
	<?php if ( isset( $options['custom_css'] ) && $options['custom_css'] != "" ): ?>
		<style type="text/css"><?php echo $options['custom_css']; ?></style>
	<?php endif; ?>
	<?php tha_head_bottom(); ?>
</head>
<body <?php body_class() ?>>
<?php if ( isset( $options['analytics_body_script_top'] ) && ! empty( $options['analytics_body_script_top'] ) ): ?>
	<?php echo $options['analytics_body_script_top']; ?>
<?php endif; ?>
<?php if ( is_single() && $enable_fb_comments != "off" && ! empty( $fb_app_id ) ) : ?>
	<?php include get_template_directory() . '/partials/fb-script.php' ?>
<?php endif; ?>
<?php tha_body_top(); ?>
<div id="floating_menu">
	<?php tha_header_before(); ?>
	<header>
		<?php tha_header_top(); ?>
		<div class="wrp" id="head_wrp">
			<?php
			if ( $options['logo_type'] == "text" ):
				?>
				<div id="text_logo"
				     class="<?php if ( $options['logo_color'] == "default" ): ?><?php echo $options['color_scheme'] ?><?php else: ?><?php echo $options['logo_color'] ?><?php endif; ?>">
					<a href="<?php echo home_url( '/' ); ?>"><?php echo $options['logo_text']; ?></a>
				</div>

			<?php elseif ( $options['logo'] && $options['logo'] != "" ): ?>
				<div id="logo"><a class="lg left" href="<?php echo home_url( '/' ); ?>">
						<img src="<?php echo $options['logo']; ?>"
						     alt="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" <?php echo $logo_width_txt . " " . $logo_height_txt; ?>/>
					</a>
				</div>
			<?php endif; ?>
		</div>
		<?php tha_header_bottom(); ?>
	</header>
	<?php tha_header_after(); ?>
</div>

<?php
if ( thrive_check_top_focus_area() ):
	thrive_render_top_focus_area();
else:
	?>
	<div class="spr"></div>
	<?php
endif;
?>
<?php tha_content_before(); ?>
<div class="wrp cnt">
	<?php tha_content_top(); ?>
